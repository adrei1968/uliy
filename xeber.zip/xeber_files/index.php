.fr-text-gray {
  color: #AAA !important;
}
.fr-text-red {
  color: #F44336 !important;
}
.fr-text-blue {
  color: #2196F3 !important;
}
.fr-text-green {
  color: #4CAF50 !important;
}
.fr-text-bordered {
  border-top: solid 1px #222;
  border-bottom: solid 1px #222;
  padding: 10px 0;
}
.fr-text-spaced {
  letter-spacing: 1px;
}
.fr-text-uppercase {
  text-transform: uppercase;
}

img.fr-dib {
  margin: 5px auto;
  display: block;
  float: none;
  vertical-align: top;
}
img.fr-dib.fr-fil {
  margin-left: 0;
}
img.fr-dib.fr-fir {
  margin-right: 0;
}
img.fr-dii {
  display: inline-block;
  float: none;
  vertical-align: bottom;
  margin-left: 5px;
  margin-right: 5px;
  max-width: calc(100% - (2 * 5px));
}
img.fr-dii.fr-fil {
  float: left;
  margin: 5px 5px 5px 0;
  max-width: calc(100% - 5px);
}
img.fr-dii.fr-fir {
  float: right;
  margin: 5px 0 5px 5px;
  max-width: calc(100% - 5px);
}
img.fr-rounded {
  border-radius: 7px;
}
img.fr-bordered {
  border: 1px solid #ddd;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
}
img.fr-padded {
  padding: 5px;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
}

img.fr-shadows {
  box-shadow: rgba(0, 0, 0, 0.29) 0px 1px 6px;
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
}

.fr-video {
  text-align: center;
  position: relative;
}
.fr-video > * {
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  max-width: 100%;
  border: none;
}
.fr-video.fr-dvb {
  display: block;
  clear: both;
}
.fr-video.fr-dvb.fr-fvl {
  text-align: left;
}
.fr-video.fr-dvb.fr-fvr {
  text-align: right;
}
.fr-video.fr-dvi {
  display: inline-block;
}
.fr-video.fr-dvi.fr-fvl {
  float: left;
}
.fr-video.fr-dvi.fr-fvr {
  float: right;
}
a.fr-strong {
  font-weight: 700;
}

table.fr-solid-borders td,
table.fr-solid-borders th {
  border: 1px solid #dddddd !important;
}

table.fr-dashed-borders td,
table.fr-dashed-borders th {
  border: 1px dashed #dddddd !important;
}

table.fr-alternate-rows tbody tr:nth-child(2n) {
  background: #f5f5f5;
}

table td.fr-red,
table th.fr-red {
  border: 1px double #F44336 !important;
}
table td.fr-blue,
table th.fr-blue {
  border: 1px double #2196F3 !important;
}
table td.fr-green,
table th.fr-green {
  border: 1px double #4CAF50 !important;
}
table td.fr-thick,
table th.fr-thick {
  border-width: 2px;
}